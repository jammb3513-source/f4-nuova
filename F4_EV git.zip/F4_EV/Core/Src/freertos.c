/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "can.h"
#include "ASSI/assi.h"
#include "CAN/CAN_Communication.h"
#include "CHECK/check.h"
#include "EBS/ebs.h"
#include "FRENO/freno.h"
#include "STERZO/sterzo.h"
#include "STERZO/epos4_command.h"
#include "IMD/IMD.h"
#include "COOLING/cooling.h"
#include "ADC/ADS1115.h"
#include "AS/as.h"
#include "map.h"
#include "TS/ts.h"
#include "settings.h"
#include "adc.h"
#include "RMD_X_V3/RMD_X_V3_Communication.h"
#include "RMD_X_V3/RMD_X_V3_Controller.h"
#include "RMD_X_V3/RMD_X_V3_Command.h"
#include "tim.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */


#define ADS1115_ADR 0x49
const float voltageConv = 6.114 / 32768.0f;

ADS1115_Config_t configReg1;
ADS1115_Handle_t *pADS1;

ADS1115_Config_t configReg2;
ADS1115_Handle_t *pADS2;

ADS1115_Config_t configReg3;
ADS1115_Handle_t *pADS3;


float lv_bat = 0;
//#define SPINTA = 1;

//RMD Freno
extern RMD_X_V3_State RMD_freno;

//Vehicle status
extern Vehicle_Status vehicle_status;

/* USER CODE END Variables */
osThreadId SendStatusHandle;
osThreadId ReadingSensorsHandle;
osThreadId DriverlessHandle;
osThreadId ElectricHandle;
osThreadId ReadingTask2Handle;

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

void play_RTDS();

/* USER CODE END FunctionPrototypes */

void SendStatus_Task(void const * argument);
void ReadingSensorsTask(void const * argument);
void Driverless_Task(void const * argument);
void Electric_Task(void const * argument);
void ReadingTask2_task(void const * argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* GetIdleTaskMemory prototype (linked to static allocation support) */
void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize );

/* USER CODE BEGIN GET_IDLE_TASK_MEMORY */
static StaticTask_t xIdleTaskTCBBuffer;
static StackType_t xIdleStack[configMINIMAL_STACK_SIZE];

void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize )
{
  *ppxIdleTaskTCBBuffer = &xIdleTaskTCBBuffer;
  *ppxIdleTaskStackBuffer = &xIdleStack[0];
  *pulIdleTaskStackSize = configMINIMAL_STACK_SIZE;
  /* place for user code */
}
/* USER CODE END GET_IDLE_TASK_MEMORY */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

//CONFIGURAZIONE INIZIALE ADS1115
	configReg1.pgaConfig = PGA_6_144;
	configReg1.operatingMode = MODE_SINGLE_SHOT;
	configReg1.dataRate = DRATE_860;
	configReg1.compareMode = COMP_HYSTERESIS;
	configReg1.polarityMode = POLARITY_ACTIVE_LOW;
	configReg1.latchingMode = LATCHING_NONE;
	configReg1.queueComparator = QUEUE_ONE;
	pADS1 = ADS1115_init(&hi2c1, ADS1115_ADR, configReg1);

	configReg2.pgaConfig = PGA_6_144;
	configReg2.operatingMode = MODE_SINGLE_SHOT;
	configReg2.dataRate = DRATE_860;
	configReg2.compareMode = COMP_HYSTERESIS;
	configReg2.polarityMode = POLARITY_ACTIVE_LOW;
	configReg2.latchingMode = LATCHING_NONE;
	configReg2.queueComparator = QUEUE_ONE;
	pADS2 = ADS1115_init(&hi2c2, ADS1115_ADR, configReg2);

	configReg3.pgaConfig = PGA_6_144;
	configReg3.operatingMode = MODE_SINGLE_SHOT;
	configReg3.dataRate = DRATE_860;
	configReg3.compareMode = COMP_HYSTERESIS;
	configReg3.polarityMode = POLARITY_ACTIVE_LOW;
	configReg3.latchingMode = LATCHING_NONE;
	configReg3.queueComparator = QUEUE_ONE;
	pADS3 = ADS1115_init(&hi2c3, ADS1115_ADR, configReg3);


  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* definition and creation of SendStatus */
  osThreadDef(SendStatus, SendStatus_Task, osPriorityHigh, 0, 128);
  SendStatusHandle = osThreadCreate(osThread(SendStatus), NULL);

  /* definition and creation of ReadingSensors */
  osThreadDef(ReadingSensors, ReadingSensorsTask, osPriorityHigh, 0, 128);
  ReadingSensorsHandle = osThreadCreate(osThread(ReadingSensors), NULL);

  /* definition and creation of Driverless */
  osThreadDef(Driverless, Driverless_Task, osPriorityHigh, 0, 128);
  DriverlessHandle = osThreadCreate(osThread(Driverless), NULL);

  /* definition and creation of Electric */
  osThreadDef(Electric, Electric_Task, osPriorityHigh, 0, 128);
  ElectricHandle = osThreadCreate(osThread(Electric), NULL);

  /* definition and creation of ReadingTask2 */
  osThreadDef(ReadingTask2, ReadingTask2_task, osPriorityHigh, 0, 256);
  ReadingTask2Handle = osThreadCreate(osThread(ReadingTask2), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

}

/* USER CODE BEGIN Header_SendStatus_Task */
/**
* @brief Function implementing the SendStatus thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_SendStatus_Task */
void SendStatus_Task(void const * argument)
{
  /* USER CODE BEGIN SendStatus_Task */
	//EPOS4_BootAndEnable(&hcan2);
	EPOS4_CAN_SendNMT(0x81, 1); // NMT Reset Node -> con il reset mandiamo il nodo in pre-operational e può ricevere SDO
	HAL_Delay(2000); //attesa bootup
	EPOS4_CAN_SendNMT(0x01, 1); // NMT Start Remote Node -> epos passa in OPERATIONAL -> avvio traffico PDO
	HAL_Delay(2000);
	sdo_write_u16(0x1017, 0x00, 1);
	sdo_write_u8(0x6060, 0x00, 8); //EPOS4_MODE_PP

	sdo_write_blocking_u16(0x6040, 0x00, 0x0006, 120); HAL_Delay(5); // Shutdown
	sdo_write_blocking_u16(0x6040, 0x00, 0x0007, 120); HAL_Delay(5); // Switch on
	sdo_write_blocking_u16(0x6040, 0x00, 0x000F, 120); HAL_Delay(5); // Enable operation
  /* Infinite loop */
	static int counter_send = 0;	//utilizzo questo counter perchè il la trasmit di SterzoFreno_EBS deve essere fatta ogni 20ms (cioè ad ogni ciclo)
	  for(;;)					//mentre la trasmit di Debug ogni 2 cicli (ogni 40ms) e quella di Stato_RMD ogni 25 cicli (cioè ogni 500ms)
	  {

		  EPOS4_Send_TargetPosition();
		  //RMD_X_V3_read_motor_status1_error_flag(&hcan2, ADDRESS_FRENO_TX, &RMD_freno);
		  //CAN_transmit_Sterzo_Freno_EBS(&hcan1);
		  osDelay(10);
		  //if( (counter_send % 25) == 0){
			  //CAN_transmit_Stato_RMD(&hcan1);
		  //}
		  //if(primo_messaggio_RES == 0){
			 // CAN_RES_Setup(&hcan1);
		 // }

		  counter_send++;
		  osDelay(20);//50
	  }
  /* USER CODE END SendStatus_Task */
}

/* USER CODE BEGIN Header_ReadingSensorsTask */
/**
  * @brief  Function implementing the ReadingSesnors thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_ReadingSensorsTask */
void ReadingSensorsTask(void const * argument)
{
  /* USER CODE BEGIN ReadingSensorsTask */
  /* Infinite loop */
  for(;;)
  {
	  configReg1.channel = CHANNEL_AIN0_GND;
	  ADS1115_updateConfig(pADS1, configReg1);
	  ADS1115_oneShotMeasure(pADS1);
	  osDelay(2);
	  suspension_adc.ant_dx = (ADS1115_getData(pADS1) * voltageConv);
	  vehicle_status.susp_ant_dx = ( (suspension_adc.ant_dx * 0.0151) - 0.136);

	  configReg1.channel = CHANNEL_AIN1_GND;
	  ADS1115_updateConfig(pADS1, configReg1);
	  ADS1115_oneShotMeasure(pADS1);
	  osDelay(2);
	  suspension_adc.ant_sx = (ADS1115_getData(pADS1) * voltageConv);
	  vehicle_status.susp_ant_sx = ( (suspension_adc.ant_sx * 0.0151) - 0.136);

	  configReg1.channel = CHANNEL_AIN2_GND;
	  ADS1115_updateConfig(pADS1, configReg1);
	  ADS1115_oneShotMeasure(pADS1);
	  osDelay(2);
	  suspension_adc.post_dx = (ADS1115_getData(pADS1) * voltageConv);
	  vehicle_status.susp_post_dx = ( (suspension_adc.post_dx * 0.0151) - 0.136);

	  configReg1.channel = CHANNEL_AIN3_GND;
	  ADS1115_updateConfig(pADS1, configReg1);
	  ADS1115_oneShotMeasure(pADS1);
	  osDelay(2);
	  suspension_adc.post_sx = (ADS1115_getData(pADS1) * voltageConv);
	  vehicle_status.susp_post_dx = ( (suspension_adc.post_dx * 0.0151) - 0.136);

	  CAN_transmit_vehicle_status_1(&hcan1);
  }
  /* USER CODE END ReadingSensorsTask */
}

/* USER CODE BEGIN Header_Driverless_Task */
/**
* @brief Function implementing the Driverless thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Driverless_Task */
void Driverless_Task(void const * argument)
{
  /* USER CODE BEGIN Driverless_Task */
  /* Infinite loop */
	ASSI_init();
	AS_init();
  /* Infinite loop */
	for(;;)
	{

//		EBS_start_toggling_watchdog();
//		osDelay(2000);
//		ebs.sdc_ready=HAL_GPIO_ReadPin(EBS_READY_READ_GPIO_Port, EBS_READY_READ_Pin);
//		EBS_stop_toggling_watchdog();
//		ebs.sdc_ready=HAL_GPIO_ReadPin(EBS_READY_READ_GPIO_Port, EBS_READY_READ_Pin);
//		osDelay(2000);


		//EBS_task();
		#ifndef SPINTA
		AS_task();
		#endif

		dati_as.asms=HAL_GPIO_ReadPin(ASMS_IN_GPIO_Port, ASMS_IN_Pin); //LETTURA ASMS
		osDelay(5);


		//CHECK PER MONITORING
		if(dati_as.stato >= AS_STATE_READY && dati_as.asms == 1){
			steering.stato_can=STATO_CAN_ON;
			brake.stato_can = STATO_CAN_ON;
		}else{
			steering.stato_can=STATO_CAN_OFF;
			brake.stato_can=STATO_CAN_OFF;
		}

		CAN_transmit_status(&hcan1);
		osDelay(1);
		CAN_transmit_dynamics1(&hcan1);
		osDelay(100);
	}
  /* USER CODE END Driverless_Task */
}

/* USER CODE BEGIN Header_Electric_Task */
/**
* @brief Function implementing the Electric thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Electric_Task */
void Electric_Task(void const * argument)
{
  /* USER CODE BEGIN Electric_Task */
  /* Infinite loop */

	dati_as.asms=HAL_GPIO_ReadPin(ASMS_IN_GPIO_Port, ASMS_IN_Pin); //LETTURA ASMS


	for(;;)
	{
		dati_as.asms=HAL_GPIO_ReadPin(ASMS_IN_GPIO_Port, ASMS_IN_Pin); //LETTURA ASMS
		dati_as.sdc = HAL_GPIO_ReadPin(SDC_READ_GPIO_Port, SDC_READ_Pin);
		ts.EV_button =HAL_GPIO_ReadPin(TS_ON_EV_GPIO_Port, TS_ON_EV_Pin);
		ts.DV_button = HAL_GPIO_ReadPin(TS_ON_DV_GPIO_Port, TS_ON_DV_Pin);
		ts.TSMS = HAL_GPIO_ReadPin(TSMS_5V_GPIO_Port, TSMS_5V_Pin);



		TS_Activation();
		//Cooling_Control();

		if(dati_as.asms == 0){
			riferimenti_ia.perc_acceleratore = 0; //potrebbe non servire
			// to check
			riferimenti_ia.brake_target = 0;
			riferimenti_ia.steering_target = 0;
			riferimenti_ia.ami = 0;
			ebs.failureEBS=0;
			brake.turn_on = 0;
			brake.sb=SB_UNAVAILABLE;
			steering.state=0;
			steering.angle = 0;
			dati_as.stato=1;
			Cones_count_actual =0;
			Cones_count_all = 0;
			primo_messaggio_freno = 0;  // TODO primo_messaggio_freno viene definito dagli RMD nella callback CAN
			primo_messaggio_sterzo = 0;  // TODO primo_messaggio_sterzo viene definito dagli RMD nella callback CAN
			brake_emergency = 0;
			flag_sterzo=0;
		}
			//DECOMMENTA A TEST SPINTA
			#ifdef SPINTA
			else{
			  dati_as.stato = 3;
			}
			#endif

			osDelay(100);

    osDelay(1);
  }
  /* USER CODE END Electric_Task */
}

/* USER CODE BEGIN Header_ReadingTask2_task */
/**
* @brief Function implementing the ReadingTask2 thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_ReadingTask2_task */
void ReadingTask2_task(void const * argument)
{
  /* USER CODE BEGIN ReadingTask2_task */
  /* Infinite loop */
  for(;;)
  {
	  //LETTURA PRESSIONE FRENI + TEMPERATURA FRENI
	  		configReg2.channel = CHANNEL_AIN1_GND;
	  		ADS1115_updateConfig(pADS2, configReg2);
	  		ADS1115_oneShotMeasure(pADS2);
	  		osDelay(2);
	  		brakesys_adc.press_ant = (ADS1115_getData(pADS2) * voltageConv);
	  		vehicle_status.press_ant = (brakesys_adc.press_ant*11) - 4.44;

	  		configReg2.channel = CHANNEL_AIN2_GND;
	  		ADS1115_updateConfig(pADS2, configReg2);
	  		ADS1115_oneShotMeasure(pADS2);
	  		osDelay(2);
	  		brakesys_adc.press_post = (ADS1115_getData(pADS2) * voltageConv);
	  		vehicle_status.press_post = (brakesys_adc.press_post*11) - 4.44;
	  //LETTURA PRESSIONE EBS
	  		HAL_ADC_Start(&hadc2);
	  		HAL_ADC_PollForConversion(&hadc2, 100);
	  		brakesys_adc.press_ebs = ((HAL_ADC_GetValue(&hadc2) * 3.3) / 4095)*11 - 4.44;
	  		HAL_ADC_Stop(&hadc2);

	  //LETTURA BATTERIA 24V
	  		HAL_ADC_Start(&hadc1);
	  		HAL_ADC_PollForConversion(&hadc1, 100);
	  		vehicle_status.voltage_24v = map( ((HAL_ADC_GetValue(&hadc1) * 3.3) / 4095), 0.0, 3.3, 0.0, 25.0);
	  		HAL_ADC_Stop(&hadc1);

      //LETTURA TEMPERATURA RADIATORI
	  		configReg3.channel = CHANNEL_AIN2_GND;
	  		ADS1115_updateConfig(pADS3, configReg3);
	  		ADS1115_oneShotMeasure(pADS3);
	  		osDelay(2);
	  		coolingsys_adc.temp_rad_sx = (ADS1115_getData(pADS3) * voltageConv);

	  		configReg3.channel = CHANNEL_AIN3_GND;
	  		ADS1115_updateConfig(pADS3, configReg3);
	  		ADS1115_oneShotMeasure(pADS3);
	  		osDelay(2);
	  		coolingsys_adc.temp_rad_dx = (ADS1115_getData(pADS3) * voltageConv);

    osDelay(1);
  }
  /* USER CODE END ReadingTask2_task */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

void play_RTDS(){
	// in AS_Task c'è una funzione per un cicalino
	// cercare la funzione e copiarla qui
	// ma modificare la durata e frequenza in base al regolamento
}
/* USER CODE END Application */

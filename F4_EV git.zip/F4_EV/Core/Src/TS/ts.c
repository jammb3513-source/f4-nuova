/*
 * ts.c
 *
 *  Created on: Aug 22, 2025
 *      Author: david
 */
#include "TS/ts.h"
#include "AS/as.h"
#include "ADC/ADS1115.h"
#include "ASSI/ASSI.h"
#include "main.h"


TS ts;
uint32_t press = 0;
uint8_t flag_on = 0;
uint8_t avg_temp = 0;
uint32_t ts_buzzer_start = 0;
extern TIM_HandleTypeDef htim3;

void TS_Activation(){
	//CONTROLLO ACCENSIONE
				if(ts.TSMS == 1 && dati_as.sdc == 1 && ts.EV_button == 1 && dati_as.asms != 1){
					ts.status = TS_ON;
				}else if (ts.TSMS == 1 && dati_as.sdc == 1 && ts.DV_button == 1){
					ts.status = TS_ON;
				}else if (dati_as.sdc == 0 || ts.TSMS == 0){
					ts.status = TS_OFF;
				}

	//DA CALIBRARE POMP MIN E POMP MAX IN BASE AI VALORI LETTI SUL MOMENTO
				if(ts.status == TS_ON && brakesys_adc.press_ant > 20 && ts.EV_button == 1 && dati_as.asms != 1){
					ts.status = R2D_ACTIVE;
					ts_buzzer_start = HAL_GetTick();
					TS_R2D_buzzer_on();
				}else if(ts.status == TS_ON && brakesys_adc.press_ant > 30 && ts.DV_button == 1){
					ts.status = R2D_ACTIVE;
				}

	//CONTROLLO SPEGNIMENTO -> TENERE PREMUTO IL TASTO PER 1 SECONDO
				if (ts.EV_button == 1) {
					if(press == 0){
						press = HAL_GetTick();
					}else if(HAL_GetTick() - press >= 1000){
						ts.status = TS_OFF;
						flag_on = 1;
					}
				}else{
					press = 0;
				}
				if((HAL_GetTick() - ts_buzzer_start) >= TS_BUZZER_DURATION){
					TS_R2D_buzzer_off();
					ts_buzzer_start = 0;
				}
}

void TS_R2D_buzzer_on(){
	htim3.Instance->CCR4 = BUZZER_ON;
}

void TS_R2D_buzzer_off(){
	htim3.Instance->CCR4 = BUZZER_OFF;
}


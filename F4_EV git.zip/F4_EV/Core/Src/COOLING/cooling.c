/*
 * cooling.c
 *
 *  Created on: Sep 4, 2025
 *      Author: fabio
 */


#include "COOLING/cooling.h"
#include "tim.h"
#include "TS/ts.h"
#include "map.h"

extern CoolingSys_adc coolingsys_prova;
extern TS ts;
extern int temp_tsac;
// ===================== VARIABILI DI STATO =====================
// Sistema Radiatore
static int pump_relay_on = 0;        // Stato relè pompa
static int pump_active = 0;          // Stato logico pompa

static int rad_fan_relay_on = 0;     // Stato relè ventole radiatore
static int rad_fan_active = 0;       // Stato logico ventole radiatore

static float current_pump_speed = 0.0f;   // Velocità corrente pompa
static float radiator_temperature = 0.0f;

// Sistema TSAC
static int tsac_fan_active = 0;      // Stato logico ventole TSAC
static float tsac_temperature = 0.0f;



// ===================== FUNZIONI CONTROLLO RELÈ =====================
void set_rad_fan_relay(int enable) {
    if (enable) {
        HAL_GPIO_WritePin(RAD_FAN_RELAY_GPIO_PORT, RAD_FAN_RELAY_GPIO_PIN, GPIO_PIN_SET);
        rad_fan_relay_on = 1;
    } else {
        HAL_GPIO_WritePin(RAD_FAN_RELAY_GPIO_PORT, RAD_FAN_RELAY_GPIO_PIN, GPIO_PIN_RESET);
        rad_fan_relay_on = 0;
    }
}

void set_pump_fan_relay(int enable) {
    if (enable) {
        HAL_GPIO_WritePin(PUMP_RELAY_GPIO_PORT, PUMP_RELAY_GPIO_PIN, GPIO_PIN_SET);
        pump_relay_on = 1;
    } else {
        HAL_GPIO_WritePin(PUMP_RELAY_GPIO_PORT, PUMP_RELAY_GPIO_PIN, GPIO_PIN_RESET);
        pump_relay_on = 0;
    }
}

// ===================== CONTROLLO SISTEMA RADIATORE =====================
void Radiator_System_Control() {
    // Lettura temperatura radiatore
    radiator_temperature = (coolingsys_prova.temp_rad_sx + coolingsys_prova.temp_rad_dx) / 2.0f;

    // =============== CONTROLLO POMPA ===============
    // Logica pwm per pompa dell'acqua

    if (ts.status == TS_AS || ts.status == R2D_ACTIVE){
    	set_pump_fan_relay(1);
        int ts_state_scaling = (ts.status == TS_AS) ? 0.5 : 1; // Scala 0.5 per AS, 1 per R2D_ACTIVE
		if(radiator_temperature > TEMP_RAD_TARGET && radiator_temperature < TEMP_RAD_EMERGENCY){
			pump_active = 1;
			current_pump_speed = ts_state_scaling * map(radiator_temperature, TEMP_RAD_TARGET, TEMP_RAD_EMERGENCY, PUMP_MIN_SPEED, PUMP_MAX_SPEED);
			__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, current_pump_speed);
		}
		else if(radiator_temperature >= TEMP_RAD_EMERGENCY){
			pump_active = 1;
			current_pump_speed = PUMP_MAX_SPEED;
			__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, current_pump_speed); //pompa al massimo
		}
		else{
			pump_active = 1;
			current_pump_speed = PUMP_MIN_SPEED;
			__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, current_pump_speed); //pompa spenta
		}
	}
    else{
    	set_pump_fan_relay(0);
    	pump_active = 0;
    	current_pump_speed = 0.0f;
    	__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, current_pump_speed); //pompa spenta
    }


    // =============== CONTROLLO VENTOLE RADIATORE ===============
    // Logica on/off con isteresi per ventole radiatore
    if (ts.status == TS_AS || ts.status == R2D_ACTIVE){
        if (radiator_temperature >= TEMP_RAD_FAN_START) {
            rad_fan_active = 1;
            set_rad_fan_relay(1);
        }
        else if (rad_fan_active && radiator_temperature >= (TEMP_RAD_FAN_START - TEMP_RAD_HYSTERESIS) && radiator_temperature < TEMP_RAD_FAN_START) {
			// Isteresi: mantieni lo stato attuale (non fare nulla)
			rad_fan_active = 1;
			set_rad_fan_relay(1);
		}
        else if (radiator_temperature < (TEMP_RAD_FAN_START - TEMP_RAD_HYSTERESIS)) {
        	rad_fan_active = 0;
        	set_rad_fan_relay(0);
        }
        else{
			rad_fan_active = 0;
			set_rad_fan_relay(0);
		}
    } else {
    	rad_fan_active = 0;
		set_rad_fan_relay(0);
    }

}

// ===================== CONTROLLO SISTEMA TSAC =====================
/*timer 14 ch 1 per TSAC*/
void TSAC_System_Control() {
    // Lettura temperatura TSAC
    tsac_temperature = temp_tsac; /* TODO: Sostituire con lettura sensore reale */

    if(tsac_temperature >= TEMP_TSAC_FAN_START && tsac_temperature < TEMP_TSAC_TARGET){
    	tsac_fan_active = 1;
    	//__HAL_TIM_SET_COMPARE(&htim14, TIM_CHANNEL_1, FAN_MIN_SPEED); //ventole al minimo
    }
    else if(tsac_temperature > TEMP_TSAC_TARGET && radiator_temperature < TEMP_TSAC_EMERGENCY){
    	tsac_fan_active = 1;
    	int fan_speed_tmp = map(tsac_temperature, TEMP_TSAC_TARGET, TEMP_TSAC_EMERGENCY, FAN_MIN_SPEED, FAN_MAX_SPEED);
    			//__HAL_TIM_SET_COMPARE(&htim14, TIM_CHANNEL_1, fan_speed_tmp);
    }
    else if(radiator_temperature >= TEMP_RAD_EMERGENCY){
    	tsac_fan_active = 1;
    	//__HAL_TIM_SET_COMPARE(&htim14, TIM_CHANNEL_1, FAN_MAX_SPEED); //pompa al massimo
    }
    else{
    	tsac_fan_active = 0;
    	//__HAL_TIM_SET_COMPARE(&htim14, TIM_CHANNEL_1, FAN_MIN_SPEED); //pompa spenta
    }

}

// ===================== FUNZIONE PRINCIPALE =====================
void Cooling_Control() {
    // Controlla sistema radiatore (pompa + ventole radiatore)
    Radiator_System_Control();

    // Controlla sistema TSAC (ventole TSAC indipendenti)
    TSAC_System_Control();
}

// =============== FUNZIONE DI DEBUG/MONITORING ===============

cooling_status_t Get_Cooling_Status() {
    cooling_status_t status;

    // Sistema Radiatore
    status.radiator_temperature = radiator_temperature;
    status.pump_active = pump_active;
    status.pump_relay_on = pump_relay_on;
    status.rad_fan_active = rad_fan_active;
    status.rad_fan_relay_on = rad_fan_relay_on;
    status.pump_speed = current_pump_speed;


    // Sistema TSAC
    status.tsac_temperature = tsac_temperature;
    status.tsac_fan_active = tsac_fan_active;

    return status;
}

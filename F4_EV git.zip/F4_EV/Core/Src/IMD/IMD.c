/*
 * IMD.c
 *
 *  Created on: Feb 5, 2025
 *      Author: Fede
 */

#include "IMD/IMD.h"

//enum StatoIMD {IMDOFF, IMD_OK, IMD_CONFIG, IMD_EMERGENCY} StatoIMD;

// riceve alarm da IMD
//attende pressione pulsante (azione aggiuntiva)
//riceve pressione pulsante
//manda "abbassa pin stato"

IMD imd;

void IMD_init(){
	//settare pin Alarm come reset manuale, settando self-holding iso-Alarm: Activation (0x31 in 0xFD)
}


void IMD_Deserialize_Status(uint8_t data[]){
	imd.R_iso_corrected = ( ( ((uint16_t)data[1]) << 8) | ((uint16_t)data[0]));
	imd.R_iso_status = data[2];
	imd.Measurement_counter = data[3];
	imd.warnings_and_alarms = ( (((uint16_t)data[5]) << 8) | ((uint16_t)data[4]));
	imd.Device_activity = data[6];
}


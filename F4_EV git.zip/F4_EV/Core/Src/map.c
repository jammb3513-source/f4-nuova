/*
 * map.c
 *
 *  Created on: Feb 11, 2021
 *      Author: ValyFox
 */

#include "main.h"
#include "map.h"
float map(float x, float a, float b, float c, float d) {
	float m =  (x - a) / (b - a) * (d - c) + c;

	if(m>d)m=d;
	if(m<c)m=c;

	return m;
}

float mapDec(float x, float a, float b, float c, float d) {
	return map(b-x, a,b,d,c);
}

uint16_t map_uint16(uint16_t x, uint16_t a, uint16_t b, uint16_t c, uint16_t d) {
	uint16_t m =  (x - a) / (b - a) * (d - c) + c;

	if(m>d)m=d;
	if(m<c)m=c;

	return m;
}



//prende il valore "x" che ha un range che va da "a" a "b" e lo mappa su un'uscita che va da "c" a "d"
int map_int(int x, int a, int b, int c, int d) {
	int m =  (int)(1.0*(x - a) / (b - a) * (d - c) + c);

	if(m>d)m=d;
	if(m<c)m=c;

	return m;
}



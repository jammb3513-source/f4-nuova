#include <STERZO/epos4_communication.h>
#include <STERZO/epos4_command.h>

#include <string.h>
#define OD_ERROR_REGISTER   0x1001   // 8 bit
#define OD_ERROR_CODE       0x603F   // 16 bit (Error code)

int32_t prova = 0;
CAN_HandleTypeDef *hcan2;
static EPOS4_Config _cfg;
static EPOS4_State  _st; //variabile interna per lo stato
static volatile int32_t _last_target_counts = 0;  // storage interno di last counts



//------------------- BOOT ---------------------------//
EPOS4_Result EPOS4_BootAndEnable(CAN_HandleTypeDef *hcan){
	 _epos4_can.hcan = hcan;
	 _epos4_can.node_id=1;
	 _cfg.node_id=1;
	 _cfg.counts_per_rev=1024;
	 _cfg.gear_ratio = 1;
	 _cfg.mode= 8;
	 _cfg.hcan= hcan;
	 _cfg.sync_period_us=60;

    //Enable per NMT STATE MACHINE
	EPOS4_CAN_SendNMT(0x81, _cfg.node_id); // NMT Reset Node -> con il reset mandiamo il nodo in pre-operational e può ricevere SDO
	HAL_Delay(2000); //attesa bootup
	EPOS4_CAN_SendNMT(0x01, _cfg.node_id); // NMT Start Remote Node -> epos passa in OPERATIONAL -> avvio traffico PDO
	HAL_Delay(2000);
	sdo_write_u16(OD_HEARTBEAT_TIME, 0x00, (uint16_t)_cfg.heartbeat_ms);
	sdo_write_u8(OD_MODES_OF_OPERATION, 0x00, (uint8_t)EPOS4_MODE_CSP); //EPOS4_MODE_PP

	sdo_write_blocking_u16(OD_CONTROLWORD, 0x00, 0x0006, 120); HAL_Delay(5); // Shutdown
	sdo_write_blocking_u16(OD_CONTROLWORD, 0x00, 0x0007, 120); HAL_Delay(5); // Switch on
	sdo_write_blocking_u16(OD_CONTROLWORD, 0x00, 0x000F, 120); HAL_Delay(5); // Enable operation


	return EPOS4_OK;
}

void EPOS4_Init(){
	 _epos4_can.hcan = hcan2;
	 _epos4_can.node_id=1;
	 _cfg.node_id=1;
	 _cfg.counts_per_rev=1024;
	 _cfg.gear_ratio = 1;
	 _cfg.mode= 8;
	 _cfg.hcan= hcan2;
	 _cfg.sync_period_us=60;

	EPOS4_CAN_SendNMT(0x81, _cfg.node_id); // NMT Reset Node -> con il reset mandiamo il nodo in pre-operational e può ricevere SDO
	HAL_Delay(2000); //attesa bootup
	EPOS4_CAN_SendNMT(0x01, _cfg.node_id); // NMT Start Remote Node -> epos passa in OPERATIONAL -> avvio traffico PDO
	sdo_write_u16(OD_HEARTBEAT_TIME, 0x00, (uint16_t)_cfg.heartbeat_ms);
	sdo_write_u8(OD_MODES_OF_OPERATION, 0x00, (uint8_t)EPOS4_MODE_CSP); //EPOS4_MODE_PP
}

void EPOS4_Enable(){
	sdo_write_blocking_u16(OD_CONTROLWORD, 0x00, 0x0006, 120); HAL_Delay(5); // Shutdown
	sdo_write_blocking_u16(OD_CONTROLWORD, 0x00, 0x0007, 120); HAL_Delay(5); // Switch on
	sdo_write_blocking_u16(OD_CONTROLWORD, 0x00, 0x000F, 120); HAL_Delay(5); // Enable operation
}
//-------------------- CALLBACK CAN-------------------------//
void EPOS4_OnCanRx(const CAN_RxHeaderTypeDef* hdr, const uint8_t* d){
  if(hdr->StdId == COB_ID_TPDO1(_epos4_can.node_id)){
    uint16_t sw = d[0] | (d[1]<<8);
    parse_status(sw);
    int32_t pos=0; memcpy(&pos, &d[2], 4);
    _st.pos_actual = pos;
  } else if(hdr->StdId == COB_ID_SDO_TX(_epos4_can.node_id)){
    EPOS4_SDO_OnRx(hdr,d);
  } else if(hdr->StdId == COB_ID_HB(_epos4_can.node_id)){
    _st.last_hb_ms = 0;
  }
}


//-------------------- AGGIORNAMENTO COUNTS ----------------------------------//
EPOS4_Result EPOS4_SetTargetAngleDeg(float angle_deg){
  if(_cfg.counts_per_rev == 0) return EPOS4_ERR_PARAM;
  const float k = (float)_cfg.counts_per_rev * _cfg.gear_ratio / 360.0f;
  _last_target_counts = (int32_t)(angle_deg * k); //aggiorna la variabile che sarà mandata via rpdo
  //prova = (int32_t)(angle_deg * k);
  return EPOS4_OK;
}


//-------------------- INVIO POSIZIONE ------------------------------------//
void EPOS4_Send_TargetPosition(void){ //Chiamata nella callback del timer da 1ms
    int32_t target = _last_target_counts;   //prendo l'ultimo set point, l'ultima target position e lo invio come rpdo
    EPOS4_SendSYNC();
    HAL_Delay(10);
    if (_cfg.mode == EPOS4_MODE_PP){
    	EPOS4_PDO_Send_RPDO1_Control_Target(0x003F, target);
    	sdo_write_blocking_u16(0x6040, 0x00, 0x000F, 120); HAL_Delay(5);
    }else if(_cfg.mode == EPOS4_MODE_CSP){
    	EPOS4_PDO_Send_RPDO1_Control_Target(0x000F, target);
    }
}


// ========================== FUNZIONI DI UTILITA'==============================//

int dir = 1; //direzione = 1 avanti, -1 = indietro
const int32_t STEP = 300;       // passo in counts
const int32_t LIM_POS = 1023;  // limite superiore
const int32_t LIM_NEG = -1023; // limite inferiore

EPOS4_Result EPOS4_STEP(){ //rampa che va avanti e torna indietro
	int32_t counts = dir * STEP;
    int32_t tmp = _last_target_counts + counts;
    _last_target_counts = tmp;
    if(tmp >= LIM_POS){dir = -1;}
    else if(tmp <= LIM_NEG){dir = +1;}
    return EPOS4_OK;
}

const EPOS4_State* EPOS4_GetState(void){ return &_st; }

void parse_status(uint16_t sw){
  _st.statusword=sw;
  _st.op_enabled = (sw & 0x0004) && (sw & 0x0020); // Ready+Operation enabled bits (rough)
  _st.fault      =  (sw & 0x0008) ? 1 : 0;
}



// ========================== EXTRA ==================================*/

EPOS4_Result EPOS4_QuickStop(void){
  uint16_t cw = 0x000B; // quick stop
  return EPOS4_PDO_Send_RPDO1_Control_Target(cw, _st.pos_actual);
}

EPOS4_Result EPOS4_FaultReset(void){
  uint16_t cw = 0x0080; // fault reset pulse
  EPOS4_PDO_Send_RPDO1_Control_Target(cw, _st.pos_actual);
  HAL_Delay(2);
  cw = 0x0006; EPOS4_PDO_Send_RPDO1_Control_Target(cw, _st.pos_actual); HAL_Delay(2);
  cw = 0x0007; EPOS4_PDO_Send_RPDO1_Control_Target(cw, _st.pos_actual); HAL_Delay(2);
  cw = 0x000F; EPOS4_PDO_Send_RPDO1_Control_Target(cw, _st.pos_actual); HAL_Delay(2);
  return EPOS4_OK;
}







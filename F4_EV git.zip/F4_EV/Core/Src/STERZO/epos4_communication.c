#include "STERZO/epos4_communication.h"
#include "CAN/CAN_driver.h"
#include <string.h>
#include <STERZO/epos4_command.h>

CAN_HandleTypeDef hcan2;
EPOS4_CanCtx _epos4_can = {0};
EPOS4_SdoXfer _sdo = {0};

HAL_StatusTypeDef EPOS4_CAN_SendStd(uint16_t id, const uint8_t* data, uint8_t len){
  return CAN_Transmit(_epos4_can.hcan, id, /*(uint8_t*)data*/ data, len);
}

void EPOS4_CAN_SendNMT(uint8_t cmd, uint8_t node_id){
  uint8_t p[2] = {cmd, node_id};
  EPOS4_CAN_SendStd(COB_ID_NMT(), p, 2);
}

void EPOS4_SendSYNC(void){
  uint8_t b = 0;
  EPOS4_CAN_SendStd(COB_ID_SYNC(), &b, 0);
}

static struct {
  uint32_t last_hb_ms;
  uint8_t  nmt_state;
} _diag;



static inline uint8_t dl_cmd(uint8_t size){
  // download expedited, size indicated
  // 1B -> 0x2F, 2B -> 0x2B, 4B -> 0x23
  return (size==1)?0x2F : (size==2)?0x2B : 0x23;
}


// RPDO1: Controlword(0x6040:00,16) + TargetPosition(0x607A:00,32), sync type 1
// TPDO1: Statusword(0x6041:00,16) + PositionActual(0x6064:00,32), sync type 1
EPOS4_Result EPOS4_PDO_Map_CSP(uint8_t node_id, uint16_t inhibit_us){
  // Disabilita mapping scrivendo 0 a subindex 0 (numero oggetti)
  EPOS4_SDO_Write(OD_RPDO1_MAPPING, 0x00, 0, 1);
  EPOS4_SDO_Write(OD_TPDO1_MAPPING, 0x00, 0, 1);

  // Scrivi voci mapping
  EPOS4_SDO_Write(OD_RPDO1_MAPPING, 0x01, MAP_U16(OD_CONTROLWORD,0x00), 4);
  EPOS4_SDO_Write(OD_RPDO1_MAPPING, 0x02, MAP_U32(OD_TARGET_POSITION,0x00), 4);
  EPOS4_SDO_Write(OD_RPDO1_MAPPING, 0x00, 2, 1); // 2 oggetti

  EPOS4_SDO_Write(OD_TPDO1_MAPPING, 0x01, MAP_U16(OD_STATUSWORD,0x00), 4);
  EPOS4_SDO_Write(OD_TPDO1_MAPPING, 0x02, MAP_U32(OD_POSITION_ACTUAL,0x00), 4);
  EPOS4_SDO_Write(OD_TPDO1_MAPPING, 0x00, 2, 1);

  // Parametri di comunicazione: COB-ID e Transmission Type=1 (synchronous every SYNC)
  EPOS4_SDO_Write(OD_RPDO1_COMM, 0x01, COB_ID_RPDO1(node_id), 4);
  EPOS4_SDO_Write(OD_RPDO1_COMM, 0x02, 1, 1);

  EPOS4_SDO_Write(OD_TPDO1_COMM, 0x01, COB_ID_TPDO1(node_id), 4);
  EPOS4_SDO_Write(OD_TPDO1_COMM, 0x02, 1, 1);
  if(inhibit_us) EPOS4_SDO_Write(OD_TPDO1_COMM, 0x03, inhibit_us, 2);

  return EPOS4_OK;
}

EPOS4_Result EPOS4_PDO_Send_RPDO1_Control_Target(uint16_t cw, int32_t target_counts){
    uint8_t d[6];
    d[0] = cw & 0xFF;
    d[1] = (cw >> 8) & 0xFF;
    memcpy(&d[2], &target_counts, 4);  // little-endian, 4 byte subito dopo il CW
    HAL_StatusTypeDef st = EPOS4_CAN_SendStd(COB_ID_RPDO1(_epos4_can.node_id), d, sizeof(d));
    return (st == HAL_OK) ? EPOS4_OK : EPOS4_ERR_COMM;
}


EPOS4_Result EPOS4_SDO_Write(uint16_t idx, uint8_t sub, uint32_t val, uint8_t size){
  if(_sdo.busy) return EPOS4_ERR_STATE;
  _sdo = (EPOS4_SdoXfer){ .busy=1, .is_read=0, .index=idx, .sub=sub, .size=size, .val=val, .timeout_ms=100, .elapsed_ms=0};
  uint8_t d[8]={0};
  d[0] = dl_cmd(size);
  d[1] = idx & 0xFF;
  d[2] = idx >> 8;
  d[3] = sub;
  memcpy(&d[4], &val, size);
  EPOS4_CAN_SendStd(COB_ID_SDO_RX(_epos4_can.node_id), d, 8);
  return EPOS4_OK;
}

EPOS4_Result EPOS4_SDO_Read(uint16_t idx, uint8_t sub, uint32_t* out, uint8_t size){
  if(_sdo.busy) return EPOS4_ERR_STATE;
  _sdo = (EPOS4_SdoXfer){ .busy=1, .is_read=1, .index=idx, .sub=sub, .size=size, .timeout_ms=100, .elapsed_ms=0};
  uint8_t d[8]={0};
  d[0] = 0x40; // upload initiate
  d[1] = idx & 0xFF;
  d[2] = idx >> 8;
  d[3] = sub;
  EPOS4_CAN_SendStd(COB_ID_SDO_RX(_epos4_can.node_id), d, 8);
  (void)out; // verrà riempito in OnRx
  return EPOS4_OK;
}


void EPOS4_SDO_OnRx(const CAN_RxHeaderTypeDef* hdr, const uint8_t* p){
  if(!_sdo.busy) return;
  if(hdr->StdId != COB_ID_SDO_TX(_epos4_can.node_id)) return;

  // check abort? (0x80)
  if(p[0] == 0x80){ _sdo.busy=0; return; }

  if(_sdo.is_read){
    // expedited upload response 0x4F/0x4B/0x43 based on size
    uint32_t val=0; memcpy(&val, &p[4], _sdo.size);
    _sdo.val = val;
  }
  _sdo.busy=0;
}

void EPOS4_SDO_Tick1ms(void){
  if(_sdo.busy && ++_sdo.elapsed_ms > _sdo.timeout_ms){ _sdo.busy=0; }
}



/*===================== SDO WRITE ============================*/
EPOS4_Result sdo_write_u8(uint16_t idx, uint8_t sub, uint8_t v){
  EPOS4_SDO_Write(idx,sub,v,1);
  // attendo completamento molto semplice (busy clear o timeout)
  uint16_t t=0; while(_sdo.busy && t++<120) HAL_Delay(1);
  return _sdo.busy?EPOS4_ERR_TIMEOUT:EPOS4_OK;
}
EPOS4_Result sdo_write_u16(uint16_t idx, uint8_t sub, uint16_t v){
  EPOS4_SDO_Write(idx,sub,v,2); uint16_t t=0; while(_sdo.busy && t++<120) HAL_Delay(1);
  return _sdo.busy?EPOS4_ERR_TIMEOUT:EPOS4_OK;
}

EPOS4_Result sdo_write_blocking_u16(uint16_t idx, uint8_t sub, uint16_t v, uint16_t to_ms){
  if(EPOS4_SDO_Write(idx, sub, v, 2) != EPOS4_OK) return EPOS4_ERR_STATE;
  uint16_t t=0; while(_sdo.busy && t++<to_ms) HAL_Delay(1);
  return _sdo.busy ? EPOS4_ERR_TIMEOUT : EPOS4_OK;
}
/*
static EPOS4_Result sdo_write_u32(uint16_t idx, uint8_t sub, uint32_t v){
  EPOS4_SDO_Write(idx,sub,v,4); uint16_t t=0; while(_sdo.busy && t++<120) HAL_Delay(1);
  return _sdo.busy?EPOS4_ERR_TIMEOUT:EPOS4_OK;
}*/


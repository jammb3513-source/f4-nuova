/*
 * CAN_driver.c
 *
 *  Created on: Feb 4, 2022
 *      Author: bianco
 */

#include "CAN/CAN_driver.h"

CAN_RxHeaderTypeDef RxHeader;
CAN_TxHeaderTypeDef TxHeader;

uint32_t mailbox;

HAL_StatusTypeDef CAN_Transmit(CAN_HandleTypeDef* hcan, uint32_t my_id, uint8_t* data, uint8_t data_length) {

	if ((hcan == NULL)  || (data == NULL) || (data_length > 8))
		return HAL_ERROR;

	TxHeader.DLC = data_length;
	TxHeader.IDE = CAN_ID_STD;
	TxHeader.RTR = CAN_RTR_DATA;
	TxHeader.StdId = my_id;

	return HAL_CAN_AddTxMessage(hcan, &TxHeader, data, &mailbox);
}


HAL_StatusTypeDef CAN_Receive(CAN_HandleTypeDef* hcan, uint32_t* my_id, uint8_t* data, uint8_t queue_number) {
	HAL_StatusTypeDef status;

	if(queue_number == 0)
		status = HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &RxHeader, data);
	else if(queue_number == 1)
		status = HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO1, &RxHeader, data);
	else
		return HAL_ERROR;
	*my_id=RxHeader.StdId;
	return status;
}

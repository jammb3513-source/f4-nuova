/*
 * ASSI.c
 *
 *  Created on: Feb 22, 2022
 *      Author: chip & ciop
 */
#include "tim.h"
#include "AS/as.h"
#include "ASSI/ASSI.h"

extern TIM_HandleTypeDef htim3; //8 secondi


void ASSI_init(){
	HAL_TIM_PWM_Start(PIN_LED_BLUE_PORT, PIN_LED_BLUE); //LED BLU
	HAL_TIM_PWM_Start(PIN_LED_GREEN_PORT, PIN_LED_GREEN); //LED VERDE
	HAL_TIM_PWM_Start(PIN_BUZZER_PORT, PIN_BUZZER); //BUZZER
	HAL_TIM_PWM_Start(PIN_LED_RED_PORT, PIN_LED_RED); // LED ROSSO
	htim3.Instance->CCR1 = LED_OFF; //BLU
	htim3.Instance->CCR2 = LED_OFF; //VERDE
	htim3.Instance->CCR3 = LED_OFF;//ROSSO
	htim3.Instance->CCR4 = LED_OFF;//BUZZER
}


void ASSI_off() {
	//stop buzzer
	dati_as.sound = OFF;
	htim3.Instance->CCR4 = BUZZER_OFF;

	htim3.Instance->CCR1 = LED_OFF; //BLU
	htim3.Instance->CCR2 = LED_OFF; //VERDE
	htim3.Instance->CCR3 = LED_OFF;//ROSSO
}

void ASSI_set_flashingBuzzer(int value){
	switch (value){
	case ASSI_blue_flashing:
		//start buzzer
		dati_as.sound = ON;
		htim3.Instance->CCR4 = BUZZER_ON;
		//stop buzzer
		//start flashing
		htim3.Instance->CCR1 = LED_FLASHING; //BLU
		htim3.Instance->CCR2 = LED_OFF; //VERDE
		htim3.Instance->CCR3 = LED_OFF;//ROSSO


		//end flashing
		//questo ordine è preservato per tutti i case
		break;
	case ASSI_blue_continuous:
		//dati_as.sound = OFF;
		htim3.Instance->CCR4 = BUZZER_OFF;
		htim3.Instance->CCR1 = LED_OFF; //VERDE
		htim3.Instance->CCR3 = LED_OFF;//ROSSO
		htim3.Instance->CCR2 = LED_ON;//BLU
		break;
	case ASSI_yellow_flashing:
		//dati_as.sound = OFF;
		htim3.Instance->CCR4 = BUZZER_OFF;
		htim3.Instance->CCR2 =  LED_OFF;//BLU //LED_OFF
		htim3.Instance->CCR3 = LED_FLASHING; //ROSSO
		htim3.Instance->CCR1 = LED_FLASHING; //VERDE
		break;
	case ASSI_yellow_continuous:
		//dati_as.sound = OFF;
		htim3.Instance->CCR4 = BUZZER_OFF;
		htim3.Instance->CCR2 = LED_OFF; //BLU
		htim3.Instance->CCR3 = LED_ON;	//ROSSO
		htim3.Instance->CCR1 = LED_ON; //VERDE
		break;
	}
}

/*
 * check.c
 *
 *  Created on: Feb 22, 2022
 */
#include "AS/as.h"
#include "CAN/CAN_communication.h"
#include "CHECK/check.h"
#include "EBS/ebs.h"
#include "FRENO/freno.h"
#include "STERZO/sterzo.h"
#include "settings.h"
#include "ADC/ADS1115.h"
//#define BYPASSAI 1
//#define BYPASSRES	1
#define BYPASSBRAKE 1
#define BYPASSSTEER	1
//#define BYPASSDASH	1
#define BYPASSPEBS 	1
//#define SENZA_FRENO 1 //Pezzotto per frenare in finish senza freno (con EBS)

uint8_t countbello = 0;
float prova_freno;


void freno_check(){

	// TODO primo_messaggio_freno viene definito dagli RMD nella callback CAN
	if(primo_messaggio_freno==1){
		if( HAL_GetTick() - brake.last_message > SOGLIA_EMERGENZA_FRENO ) {
			brake.sb=SB_UNAVAILABLE;
			ebs.failureEBS = 1;
		//EBS_stop_toggling_watchdog();
			dati_as.asb_check=ASB_OFF;
		}else{;
			if(prova_freno < 0.5)
				brake.sb=SB_AVAILABLE;
			else
				brake.sb=SB_ENGAGED;

			dati_as.asb_check=ASB_ON;
			//ebs.failureEBS = 0;
		}
	}
}

void sterzo_check(){

	// TODO primo_messaggio_sterzo viene definito dagli RMD nella callback CAN
	if(primo_messaggio_sterzo==1){
		if( HAL_GetTick() - steering.last_message > SOGLIA_EMERGENZA_STERZO ){
			steering.state=STERZO_FAILURE_CHECK;
			ebs.failureEBS = 1;
        //EBS_stop_toggling_watchdog();
		}
		else {
			steering.state = STEERING_STATE_AVAILABLE;
			//steering.state=0;
			//ebs.failureEBS = 0;
		}
	}
}


void continous_monitoring(){
	ebs.sdc_ready=HAL_GPIO_ReadPin(SDC_READ_GPIO_Port, SDC_READ_Pin);

	//Se lo stato è:AS_STATE_READY - AS_STATE_DRIVING - AS_STATE_EMERGENCY - AS_STATE_FINISHED
	if(dati_as.stato >= AS_STATE_READY){  //ho levato && dati_as.stato <= AS_METTI_MARCIA
		ebs.failureEBS = 0;
		if(riferimenti_ia.ami==7 || riferimenti_ia.mission_finished == 1 || brakesys_adc.press_ebs <= 1/*|| (dati_as.stato == AS_STATE_DRIVING && res.enable_go == 0 && res.emergenza == 1)*/){
			EBS_stop_toggling_watchdog();
			ebs.state = EBS_STATE_ACTIVATED;
		}

#ifdef SENZA_FRENO

		if(riferimenti_ia.isBraking == 1 && riferimenti_ia.mission_finished == 0){
			EBS_stop_toggling_watchdog();
			ebs.sdc_ready = 1;
		}
#endif
		HAL_Delay(10);
		ebs.sdc_ready=HAL_GPIO_ReadPin(SDC_READ_GPIO_Port, SDC_READ_Pin);

		if(ebs.sdc_ready==OFF || res.emergenza == 0 ){
			if(ebs.state < 4)
				ebs.state = EBS_STATE_ACTIVATED;

			if(brakesys_adc.press_ant< EBS_POMP_MIN || brakesys_adc.press_ant > EBS_POMP_MAX){
				ebs.failureEBS=1;
			}
			if(brakesys_adc.press_post< EBS_POMP_MIN || brakesys_adc.press_post > EBS_POMP_MAX){
				ebs.failureEBS=1;
			}
			if(ebs.failureEBS == 0 && dati_as.stato != AS_STATE_FINISHED){
				countbello = 0;
				EBS_start_toggling_watchdog();
			}

		}else{
			//ebs.failureEBS = 0;

#ifdef BYPASSAI
			if(primo_messaggio_AI==1 && (dati_as.stato == AS_STATE_READY||dati_as.stato == AS_STATE_DRIVING) ){
			//	if(HAL_GetTick()-riferimenti_ia.last_message> SOGLIA_EMERGENZA_IA){ //1000
			//		ebs.failureEBS=1; //in EMERGENZA DOPO 10s //SOSTITUIRE CON STOP_TOGGLING PER EMERGENCY SUBITO
			//	}
			}
#endif

#ifdef BYPASSDASH
			if(primo_messaggio_DASH==1){
			//	if(HAL_GetTick()-dati_dash.last_message> SOGLIA_EMERGENZA_DATI_DASH){ //1000
			//		ebs.failureEBS=1; //in EMERGENZA DOPO 10s //SOSTITUIRE CON STOP_TOGGLING PER EMERGENCY SUBITO
			//	}
			}
#endif

#ifdef BYPASSRES
			if(primo_messaggio_AI==1 && (dati_as.stato == AS_STATE_READY||dati_as.stato == AS_STATE_DRIVING) ) {
		//	if(primo_messaggio_RES==1){
			//	if(HAL_GetTick()-res.last_message> SOGLIA_EMERGENZA_RES){ //500
				//	ebs.failureEBS=1; //in EMERGENZA DOPO 10s //SOSTITUIRE CON STOP_TOGGLING PER EMERGENCY SUBITO
				//	}
		//		}
			}
#endif

#ifdef	BYPASSBRAKE
			if(brake.stato_can==STATO_CAN_ON) {
				freno_check();
				if(brake.sb==SB_UNAVAILABLE){
					ebs.failureEBS=1; //in EMERGENZA DOPO 10s //SOSTITUIRE CON STOP_TOGGLING PER EMERGENCY SUBITO
				}
			}
#endif

#ifdef	BYPASSSTEER
			if(steering.stato_can==STATO_CAN_ON){
				sterzo_check();
				if(steering.state==STERZO_FAILURE_CHECK){
					ebs.failureEBS=1; //in EMERGENZA DOPO 10s //SOSTITUIRE CON STOP_TOGGLING PER EMERGENCY SUBITO
				}
			}
#endif

#ifdef BYPASSPEBS
			if(brakesys_adc.press_ebs < EBS_TANK_MIN){
				ebs.failureEBS = 1;
				//EBS_stop_toggling_watchdog();
				brake_emergency = 1;
			}
			if(brakesys_adc.press_ant< EBS_POMP_MIN || brakesys_adc.press_ant > EBS_POMP_MAX){
				ebs.failureEBS=1;
				brake_emergency = 1;
			}
			if(brakesys_adc.press_post< EBS_POMP_MIN || brakesys_adc.press_post > EBS_POMP_MAX){
				ebs.failureEBS=1;
				brake_emergency = 1;
			}
#endif


			if(ebs.failureEBS==1){
				countbello ++;
			}
			if(countbello > 10){ //>= 1 PER ANDARE SUBITO IN EMERGENCY
				countbello = 0;
				EBS_stop_toggling_watchdog();
				ebs.state |= 4; //mette in failure la dash perche fa la OR con il 3 bit e quindi mette in
				//ebs.state un numero con il 3 bit alto.
				//E` la stessa condizione che si verifica in check ebs, anche per questa c`e` una mschera che risolve
				//vedi riga 62 di ebs.c
			}else {
				//ebs.state = EBS_STATE_ARMED;
			}
		}
	}

	else if( dati_as.stato==AS_STATE_OFF && ebs.primo_check==ON && dati_as.asms==ON){
		if(brakesys_adc.press_ebs> EBS_TANK_MIN && brakesys_adc.press_ant>CHECK_MIN_PRESS_POMP){
			dati_as.asb_check=ASB_ON;
			ebs.state&=0b00000011;
		}else{
			dati_as.asb_check=ASB_OFF;
			ebs.state |= 4;
		}

	}

}






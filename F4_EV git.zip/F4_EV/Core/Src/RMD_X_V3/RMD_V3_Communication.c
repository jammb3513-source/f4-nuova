#include "RMD_X_V3/RMD_X_V3_communication.h"
#include "string.h"
RMD_X_V3_Message message;
//RMD_X_State_RAW state_raw;

void RMD_X_V3_CAN_receive_state(uint8_t* data_in, RMD_X_V3_State* state, RMD_X_V3_State_RAW* state_raw){

	*(uint64_t*)(&message) = *(uint64_t*)data_in;
	/*
	message.commandByte = data_in[0];
	message.data1 = data_in[1];
	message.data2 = data_in[2];
	message.data3 = data_in[3];
	message.data4 = data_in[4];
	message.data5 = data_in[5];
	message.data6 = data_in[6];
	message.data7 = data_in[7];
	*/
	RMD_X_V3_RAW_clear_replyPending(state);
	RMD_X_V3_RAW_deserialize(&message, state_raw);
	//RMD_X_update_state(state,reduction_ratio, &state_raw);

}
void RMD_X_V3_CAN_receive_motion_mode_state(uint8_t* data_in, RMD_X_V3_State* state, RMD_X_V3_State_RAW* state_raw){

	*(uint64_t*)(&message) = *(uint64_t*)data_in;
	/*
	message.commandByte = data_in[0];
	message.data1 = data_in[1];
	message.data2 = data_in[2];
	message.data3 = data_in[3];
	message.data4 = data_in[4];
	message.data5 = data_in[5];
	message.data6 = data_in[6];
	message.data7 = data_in[7];
	*/
	RMD_X_V3_RAW_clear_replyPending(state);
	//RMD_X_V3_RAW_deserialize(&message, state_raw);
	RMD_X_V3_RAW_reply_motion_mode_control(&message, state_raw);
	//RMD_X_update_state(state,reduction_ratio, &state_raw);

}
void RMD_X_V3_Send_Data(CAN_HandleTypeDef* hcan, uint32_t address, RMD_X_V3_Message* message,RMD_X_V3_State * state){
		uint8_t data_out [8];

		/*data_out[0] = message->commandByte;
		data_out[1] = message->data1;
		data_out[2] = message->data2;
		data_out[3] = message->data3;
		data_out[4] = message->data4;
		data_out[5] = message->data5;
		data_out[6] = message->data6;
		data_out[7] = message->data7;*/

		memcpy(data_out, message,8);

		RMD_X_V3_RAW_set_replyPending(state);

		HAL_StatusTypeDef stato = CAN_Transmit(hcan, address, data_out, 8);
		if(stato == HAL_ERROR){
			HAL_CAN_AbortTxRequest(hcan, CAN_TX_MAILBOX0);
			HAL_CAN_AbortTxRequest(hcan, CAN_TX_MAILBOX1);
			HAL_CAN_AbortTxRequest(hcan, CAN_TX_MAILBOX2);
			HAL_CAN_ResetError(hcan);
			HAL_CAN_Stop(hcan);
			HAL_CAN_Start(hcan);
		}


}

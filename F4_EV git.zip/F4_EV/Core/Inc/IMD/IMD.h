/*
 * IMD.h
 *
 *  Created on: Feb 5, 2025
 *      Author: Fede
 */

#ifndef CORE_INC_IMD_IMD_H_
#define CORE_INC_IMD_IMD_H_
#include "main.h"

typedef struct IMD{
	uint16_t R_iso_corrected;
	uint8_t R_iso_status;
	uint8_t Measurement_counter;
	uint16_t warnings_and_alarms;
	uint8_t Device_activity;
}IMD;

void IMD_init();
void IMD_Deserialize_Status(uint8_t data[]);

#endif /* CORE_INC_IMD_IMD_H_ */

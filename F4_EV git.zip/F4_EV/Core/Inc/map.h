/*
 * map.h
 *
 *  Created on: Feb 11, 2021
 *      Author: ValyFox
 */

#ifndef INC_MAP_H_
#define INC_MAP_H_

float map(float x, float a, float b, float c, float d);
float mapDec(float x, float a, float b, float c, float d);

uint16_t map_uint16(uint16_t x, uint16_t a, uint16_t b, uint16_t c, uint16_t d);

int map_int(int x, int a, int b, int c, int d) ;

#endif /* INC_MAP_H_ */

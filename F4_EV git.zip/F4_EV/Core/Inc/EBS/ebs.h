/*
 * ebs.h
 *
 *  Created on: Feb 19, 2022
 *      Author: utente
 */

#ifndef INC_EBS_EBS_H_
#define INC_EBS_EBS_H_
#include "main.h"
#define ON       1
#define OFF      0

#define EBS_STATE_UNAVAILABLE                 1
#define EBS_STATE_ARMED                       2
#define EBS_STATE_ACTIVATED                   3
#define EBS_STATE_DEACTIVATED             	  4 // inutilizzato

#define EBS_STATE_SDC_OPEN                    5 // inutilizzato
#define EBS_STATE_FAILURE_SDC                 6
#define EBS_STATE_SDC_READY                   7 // inutilizzato
#define EBS_STATE_FAILURE_ENERGY_STORAGE      8
#define EBS_STATE_ENERGY_STORAGE_FILLED       9 // inutilizzato
#define EBS_STATE_FAILURE_BRAKE_PRESSURE      10
#define EBS_STATE_FAILURE_CHECK_AS            11
#define EBS_STATE_CHECK_EBS                   12 // inutilizzato

extern uint8_t brake_emergency;

typedef struct EBS{
	uint8_t state;
    uint8_t energy_storage;
    uint8_t brake_pressure;
    uint8_t primo_check;
    uint8_t sdc_ready;
    uint8_t failureEBS;
}EBS;
extern EBS ebs;

void EBS_task();
void EBS_check();
void EBS_continous_monitoring();
void EBS_failure(int failure);

#define EBS_start_toggling_watchdog() ( HAL_GPIO_WritePin(CHECK_GPIO_Port	, GPIO_PIN_13, RESET)/*HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1)*/)
#define EBS_stop_toggling_watchdog() (HAL_GPIO_WritePin(CHECK_GPIO_Port	, GPIO_PIN_13, SET)/*HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_1)*/)

#endif /* INC_EBS_EBS_H_ */




/*
 * CAN_communication.h
 *
 *  Created on: 16 mar 2022
 *      Author: Chip & Ciop
 */

#ifndef INC_CAN_CAN_COMMUNICATION_H_
#define INC_CAN_CAN_COMMUNICATION_H_

#define STERZO_FRENO_EBS		0x120
#define VOLANTE					0X110
#define DASH_STATUS 			0x301
#define VEHICLE_STATUS_1        0x121
#define VEHICLE_STATUS_2        0x122
#define RIFERIMENTI_IA			0x100
#define RES_ADDRESS				0x191
#define DV_DYNAMICS1			0x500
#define DV_DYNAMICS2			0x501
#define DV_SYSTEM_STATUS		0x502

// IMD
#define IMD_REQUEST					0x22
#define IMD_RESPONSE				0x23
#define IMD_INFO_GENERAL			0x37
#define IMD_INFO_ISOLATIONDETAIL	0x38
#define IMD_INFO_VOLTAGE			0x39
#define IMD_INFO_ITSYSTEM			0x3A

// IMD Index (Data0)
#define IMD_I_AUTO_ALARM_ACTIVATION		0x31
#define IMD_I_RESET_ALARM				0x33

// RMD Freno
#define ADDRESS_FRENO_TX	        0x141
#define ADDRESS_FRENO_RX	        0x241
#define ADDRESS_FRENO_MOTION_MODE_TX		0x401
#define ADDRESS_FRENO_MOTION_MODE_RX		0x501
#define ADDRESS_STATO_RMD		0x125


#define FILTER_NUMBER 14
#define NUMBER_ADDRESS_MAX 14


typedef struct {
	HAL_StatusTypeDef can1; // ... è l'unico campo utilizzato
//	HAL_StatusTypeDef can2;
//	uint8_t trasmit_error;
}Can_Communication;

typedef struct Sterzo_Freno_EBS{
	uint8_t	as;
	uint8_t	ebs;
	uint8_t throttle_position;
	uint8_t brake_state;
	uint8_t	brake_hydr_actual;
	uint8_t steering_state;	//prima era int8_t steering state
	int16_t	steering_actual;
}Sterzo_Freno_EBS;

typedef struct Debug{
//	uint16_t posizione_sterzo;
//	uint8_t posizione_frizione;
//	uint8_t coppia_freno;
//	uint8_t folle;
	uint8_t drs;  // TODO è var combustion?
}Debug;
extern Debug debug;

typedef struct Volante{
//	uint16_t potenziometro_frizione;
//	uint8_t paddle; //paddle_su, paddle_giu/folle	GIUSTO?????
	uint8_t AMI_provvisorio;
	uint8_t AMI_comunicato;
	uint8_t LC_TC;	//LC(4 bit) TC(4 bit)  // TODO è var combustion?
	uint8_t radio;
	uint8_t jatson;
	uint8_t antiroll_DRS; //antiroll(4 bit) DRS(4 bit)  // TODO è var combustion?
}Volante;

/* TODO: da cancellare*/
/*typedef struct Dati_DASH{
	int16_t pompante_post;
	int16_t pompante_ant;
	uint16_t potenziometro_volante;
	uint16_t press_ebs;
}Dati_DASH;
extern Dati_DASH dati_dash;
*/

/* TODO: da capire se serve che la dash invii dati all'F4*/
typedef struct Dash_status{
	uint8_t value0;
	uint8_t value1;
	uint8_t value2;
}Dash_status;
extern Dash_status dash_status;

/* TODO: In teoria non serve*/
/*typedef struct Vehicle_status{
	uint8_t susp_ant_sx;
	uint8_t susp_ant_dx;
	uint8_t susp_post_sx;
	uint8_t susp_post_dx;
	uint8_t brake_pressure_ant;
	uint8_t brake_pressure_post;
	uint8_t brake_temperature;
	uint8_t throttle_position;
}Vehicle_status;
extern Vehicle_status vehicle_status;*/

typedef struct Riferimenti_IA {
	uint8_t perc_acceleratore;
	uint8_t speed_target;
	int16_t steering_target;
	uint8_t brake_target;
	uint8_t mission_finished;
	uint8_t ami;
	uint8_t FLAG_futuro;
} Riferimenti_IA;
extern Riferimenti_IA riferimenti_ia;

typedef struct Stato_RMD{
	int8_t voltaggio_batteria_48V;
	uint8_t	freno_temperatura;
}Stato_RMD;
Stato_RMD stato_RMD;

typedef struct RES{
	uint8_t emergenza;
	uint8_t enable_go;
	uint8_t go;
} RES;
extern RES res;

typedef struct{
	uint16_t ant_dx;
	uint16_t post_sx;
	uint16_t post_dx;
	uint16_t ant_sx;
} FONICATA;
extern FONICATA fonicata;

//CAN-INS

typedef struct EulerAngles{
	int16_t roll;
	int16_t pitch;
	int16_t yaw;
}EulerAngles;
extern EulerAngles angle;

typedef struct RateOfTurn{
	int16_t gyrX;
	int16_t gyrY;
	int16_t gyrZ;
}RateOfTurn;
extern RateOfTurn rot;

typedef struct Acceleration{
	int16_t accX;
	int16_t accY;
	int16_t accZ;
}Acceleration;
extern Acceleration acceleration;

typedef struct Velocity{
	int16_t velX;
	int16_t velY;
	int16_t velZ;
}Velocity;
extern Velocity velocity;

extern uint8_t primo_messaggio_RES;
extern uint8_t Cones_count_actual;
extern uint16_t Cones_count_all;

void CAN_transmit_Sterzo_Freno_EBS(CAN_HandleTypeDef* hcan);
void CAN_vehicle_Status(CAN_HandleTypeDef* hcan);
HAL_StatusTypeDef CAN_RES_Setup (CAN_HandleTypeDef* hcan);
void CAN_transmit_dynamics1(CAN_HandleTypeDef* hcan);
void CAN_transmit_dynamics2(CAN_HandleTypeDef* hcan);
void CAN_transmit_status(CAN_HandleTypeDef* hcan);
void CAN_transmit_Stato_RMD(CAN_HandleTypeDef* hcan);
void CAN_transmit_vehicle_status_1( CAN_HandleTypeDef* hcan);
void CAN_receive_state(uint8_t data[],CAN_RxHeaderTypeDef My_header);
void CAN_serializate_gen(uint8_t data_out[], void* data_in, unsigned int dim_struct);
void CAN_deserializate_gen(uint8_t data_in[], void* data_out, unsigned int dim_struct);
void CAN_ErrorRestart(CAN_HandleTypeDef* hcan);

void CAN_sendStatus_IMD_OK(CAN_HandleTypeDef* hcan);

#endif /* INC_CAN_CAN_COMMUNICATION_H_ */

/*
 * PDM.h
 *
 *  Created on: Sep 6, 2025
 *      Author: fabio
 */

#ifndef INC_PDM_PDM_H_
#define INC_PDM_PDM_H_


typedef struct{


}Compound;

#endif /* INC_PDM_PDM_H_ */

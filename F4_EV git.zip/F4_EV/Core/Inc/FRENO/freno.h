/*
 * freno.h
 *
 *  Created on: 21 feb 2022
 *      Author: chip e ciop
 */

#ifndef INC_FRENO_FRENO_H_
#define INC_FRENO_FRENO_H_

#include "main.h"

#define SB_UNAVAILABLE           1
#define SB_ENGAGED               2
#define SB_AVAILABLE             3
#define SB_RELEASED              4 // inutilizzato


extern uint8_t primo_messaggio_freno;


typedef struct FRENO{
    uint8_t stato_can;
    uint8_t  sb;
    uint8_t turn_on;
	uint32_t last_message;
}FRENO;
extern FRENO brake;


#endif /* INC_FRENO_FRENO_H_ */

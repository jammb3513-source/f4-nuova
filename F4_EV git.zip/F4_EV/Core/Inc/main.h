/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

// fix per "_close will always fail"
__attribute__((weak)) void _close(void){}
__attribute__((weak)) void _lseek(void){}
__attribute__((weak)) void _read(void){}
__attribute__((weak)) void _write(void){}
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define CHECK_Pin GPIO_PIN_13
#define CHECK_GPIO_Port GPIOC
#define ASMS_IN_Pin GPIO_PIN_0
#define ASMS_IN_GPIO_Port GPIOC
#define SDC_READ_Pin GPIO_PIN_1
#define SDC_READ_GPIO_Port GPIOC
#define EBS_READY_READ_Pin GPIO_PIN_3
#define EBS_READY_READ_GPIO_Port GPIOC
#define battery24_measure_Pin GPIO_PIN_0
#define battery24_measure_GPIO_Port GPIOA
#define Pressione_EBS_Pin GPIO_PIN_1
#define Pressione_EBS_GPIO_Port GPIOA
#define USART_TX_Pin GPIO_PIN_2
#define USART_TX_GPIO_Port GPIOA
#define USART_RX_Pin GPIO_PIN_3
#define USART_RX_GPIO_Port GPIOA
#define SWITCH_APPS_Pin GPIO_PIN_4
#define SWITCH_APPS_GPIO_Port GPIOA
#define POMPE_CTRL_Pin GPIO_PIN_5
#define POMPE_CTRL_GPIO_Port GPIOA
#define VENTOLE_RAD_CTRL_Pin GPIO_PIN_6
#define VENTOLE_RAD_CTRL_GPIO_Port GPIOA
#define VENTOLE_TSAC_CTRL_Pin GPIO_PIN_7
#define VENTOLE_TSAC_CTRL_GPIO_Port GPIOA
#define TS_ON_EV_Pin GPIO_PIN_4
#define TS_ON_EV_GPIO_Port GPIOC
#define LUCE_FRENO_Pin GPIO_PIN_5
#define LUCE_FRENO_GPIO_Port GPIOC
#define TSMS_5V_Pin GPIO_PIN_0
#define TSMS_5V_GPIO_Port GPIOB
#define AS_CLOSE_Pin GPIO_PIN_15
#define AS_CLOSE_GPIO_Port GPIOB
#define ASSI_BLU_Pin GPIO_PIN_6
#define ASSI_BLU_GPIO_Port GPIOC
#define ASSI_VERDE_Pin GPIO_PIN_7
#define ASSI_VERDE_GPIO_Port GPIOC
#define ASSI_ROSSO_Pin GPIO_PIN_8
#define ASSI_ROSSO_GPIO_Port GPIOC
#define PWM_AS_EMERGENCY_Pin GPIO_PIN_9
#define PWM_AS_EMERGENCY_GPIO_Port GPIOC
#define RESET_IMD_Pin GPIO_PIN_10
#define RESET_IMD_GPIO_Port GPIOA
#define TMS_Pin GPIO_PIN_13
#define TMS_GPIO_Port GPIOA
#define TCK_Pin GPIO_PIN_14
#define TCK_GPIO_Port GPIOA
#define PWM_POMPE_Pin GPIO_PIN_15
#define PWM_POMPE_GPIO_Port GPIOA
#define SWO_Pin GPIO_PIN_3
#define SWO_GPIO_Port GPIOB
#define TS_ON_DV_Pin GPIO_PIN_5
#define TS_ON_DV_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */
typedef struct{
	float susp_ant_sx;
	float susp_ant_dx;
	float susp_post_sx;
	float susp_post_dx;
	int press_ant;
	int press_post;
	int press_ebs;
	float voltage_24v;
}Vehicle_Status;

#define SUSP_MIN_VAL 0.0f
#define SUSP_MAX_VAL 5.0f

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

/*
 * RMD_X_V3_command.h
 *
 *  Created on: 02 March 2023
 *      Author: Davide
 */

#ifndef INC_RMD_X_V3_COMMAND_H_
#define INC_RMD_X_V3_COMMAND_H_

#define DPS_TO_RPM 0.16667 // 1/6
#define RPM_TO_DPS 6
#define ENCODER_MAX_VALUE 16383


#include "RMD_X_V3/RMD_X_V3_Controller.h"

#define RMD_X_V3_write_pid_parameter(hcan,address ,Current_KP,Current_KI,Speed_KP,Speed_KI,Position_KP,Position_KI,state) (RMD_X_V3_RAW_command_write_pid_parameter_to_rom(hcan,address ,Current_KP,Current_KI,Speed_KP,Speed_KI,Position_KP,Position_KI,state))
#define RMD_X_V3_read_single_turn_encoder(hcan, address ,state)(RMD_X_V3_RAW_command_read_single_turn_encoder(hcan, address ,state))
#define RMD_X_V3_read_multi_turn_angle(hcan,address, state)(RMD_X_V3_RAW_command_read_multi_turn_angle(hcan,  address, state))
#define RMD_X_V3_read_single_turn_angle(hcan,  address ,state)(RMD_X_V3_RAW_command_read_single_turn_angle(hcan,  address ,state))
#define RMD_X_V3_read_motor_status1_error_flag(hcan,  address ,  state)(RMD_X_V3_RAW_command_read_motor_status1_error_flag(hcan,  address ,  state))
#define RMD_X_V3_read_motor_status2( hcan,  address , state)(RMD_X_V3_RAW_command_read_motor_status2( hcan,  address ,  state))
#define RMD_X_V3_read_motor_status3( hcan,  address , state)(RMD_X_V3_RAW_command_read_motor_status3( hcan,  address , state))
#define RMD_X_V3_motor_shutdown( hcan,  address , state)(RMD_X_V3_RAW_command_motor_shutdown( hcan,  address , state))
void RMD_X_V3_torque_closed_loop_control(CAN_HandleTypeDef* hcan, uint32_t address ,float ampere, RMD_X_V3_State * state);
void RMD_X_V3_speed_closed_loop_control(CAN_HandleTypeDef* hcan, uint32_t address ,uint8_t reduction_ratio, float rpm, RMD_X_V3_State * state);
void RMD_X_V3_absolute_position_closed_loop_control(CAN_HandleTypeDef* hcan, uint32_t address ,uint8_t reduction_ratio, float limitRpm, float positionControlGradi, RMD_X_V3_State * state);
void RMD_X_V3_single_turn_position_control(CAN_HandleTypeDef* hcan, uint32_t address ,uint8_t reduction_ratio, int spinDirection, float limitRpm, float positionControlGradi,RMD_X_V3_State * state);
void RMD_X_V3_motion_mode_control(CAN_HandleTypeDef* hcan, uint32_t address ,float pos_gradi, float speed, float KP, float KD, float t_ff, RMD_X_V3_State * state);
void RMD_X_V3_RAW_command_incremental_position_closed_loop_control(CAN_HandleTypeDef* hcan, uint32_t address , int32_t angleControl, uint16_t maxSpeed,RMD_X_V3_State * state);
#define RMD_X_V3_motor_power_acquisition(hcan, address , state) (RMD_X_V3_RAW_command_motor_power_acquisition(hcan, address , state))
#define RMD_X_V3_RAW_command_system_brake_release_state(hcan, address , state)(RMD_X_V3_RAW_command_system_brake_release_state(hcan, address , state))
#define RMD_X_V3_RAW_command_system_brake_lock(hcan, address , state)(RMD_X_V3_RAW_command_system_brake_lock(hcan, address , state))

void RMD_X_V3_update_state(RMD_X_V3_State* state, uint8_t reduction_ratio, RMD_X_V3_State_RAW* state_raw );

#endif /* INC_RMD_X_COMMAND_H_ */

/*
 * RMD_X_V3_Controller.h
 *
 *  Created on: 27 feb 2023
 *      Author: Davide
 */
#ifndef INC_RMD_X_V3_CONTROLLER_H_
#define INC_RMD_X_V3_CONTROLLER_H_
#include "main.h"
#include "CAN/CAN_driver.h"

//ID COMDANDI V3
#define READ_PID_PARAMETER 										0x30
#define WRITE_PID_PARAMETER_TO_ROM 								0x32
#define READ_SINGLE_TURN_ENCODER 								0x90
#define READ_MULTI_TURN_ANGLE									0x92
#define READ_SINGLE_TURN_ANGLE									0x94
#define READ_MOTOR_STATUS1_ERROR_FLAG 							0x9A
#define READ_MOTOR_STATUS2										0x9C
#define READ_MOTOR_STATUS3										0x9D
#define MOTOR_SHUTDOWN											0x80
#define TORQUE_CLOSED_LOOP_CONTROL								0xA1
#define SPEED_CLOSED_LOOP_CONTROL								0xA2
#define ABSOLUTE_POSITIION_CLOSED_LOOP_CONTROL					0xA4
#define SINGLE_TURN_POSITION_CONTROL							0xA6
#define INCREMENTAL_POSITION_CLOSED_LOOP_CONTROL				0xA8
#define MOTOR_POWER_ACQUISITION									0x71
#define SYSTEM_BRAKE_RELEASE									0x77
#define SYSTEM_BRAKE_LOCK										0x78
#define SYSTEM_RESET_COMMAND									0x76
#define ENCODER_MULTI_TURN_VALUE_TO_ROM_ZERO_CMD 				0x63

typedef struct RMD_X_V3_State {
	uint16_t	encoderPosition;
//	uint16_t	encoderOriginalPosition;
//	uint16_t	encoderOffset;
//
//	float	encoderPositionGradi; //gradi
//	float	encoderOriginalPositionGradi; //gradi
//	float	encoderOffsetGradi; //gradi

	float	angle;	//7 byte su 8 -- 0.01° per ogni bit

//	float	singleAngle; //gradi

	uint8_t motorTemperature;
	float 	voltage; //50,7
	int errorLowVoltage;
	int errorOverTemperature;

	float	torqueCurrent; //Ampere [-33, 33]
	uint16_t speedDPS; //Gradi al secondo
	float		speedRPM; //Rotazioni al minuto
	uint8_t replyPending;
	uint8_t 	CurrKP;
	uint8_t 	CurrKI;
	uint8_t 	SpeedKP;
	uint8_t 	SpeedKI;
	uint8_t 	PosKP;
	uint8_t 	PosKI;

	/*RMD Motion reply value converted*/
	uint8_t  CANID;
	float motion_position;
	float motion_speed;
	float motion_torque;


} RMD_X_V3_State;

typedef struct RMD_X_V3_State_RAW {
	uint8_t 	CurrKP;
	uint8_t 	CurrKI;
	uint8_t 	SpeedKP;
	uint8_t 	SpeedKI;
	uint8_t 	PosKP;
	uint8_t 	PosKI;

	int32_t 	motorAngle;
	uint16_t	circleAngle;
	uint8_t 	BrakeReleaseCommand;
	uint16_t 	speedLimit;
	uint16_t 	motorPower;	//Prima era uint8_t ma il valore che riceviamo è su 16bit

	uint16_t	encoderPosition; //gradi
	uint16_t	encoderOriginalPosition; //gradi
	uint16_t	encoderOffset; //gradi

	int64_t	angle;	//7 byte su 8 -- 0.01 ° / LSB

	uint16_t	singleAngle;

	int8_t 	motorTemperature;
	uint16_t 	voltage;
	uint16_t 	errorState;

	int16_t	torqueCurrent; //Ampere [-33, 33]
	int16_t	speed; //Gradi al secondo

	/*RMD Motion reply value*/
	uint8_t  CANID;
	uint16_t p_des;
	uint16_t v_des;
	uint16_t t_ff;
} RMD_X_V3_State_RAW;

typedef struct RMD_X_V3_Message{
	uint8_t commandByte; //identificativo comando (0x30 - 0xA6)
	uint8_t data1; //Byte per le variabili
	uint8_t data2;
	uint8_t data3;
	uint8_t data4;
	uint8_t data5;
	uint8_t data6;
	uint8_t data7;
}RMD_X_V3_Message;

//COMANDI V3
void RMD_X_V3_RAW_set_replyPending(RMD_X_V3_State * state);
void RMD_X_V3_RAW_clear_replyPending(RMD_X_V3_State * state);
int RMD_X_V3_RAW_status_low_voltage_protection( RMD_X_V3_State_RAW* state_raw);
int RMD_X_V3_RAW_status_over_temperature_protection( RMD_X_V3_State_RAW* state_raw);
void RMD_X_V3_RAW_command_write_pid_parameter_to_rom(CAN_HandleTypeDef* hcan, uint32_t address ,uint8_t Current_KP, uint8_t Current_KI, uint8_t Speed_KP, uint8_t Speed_KI, uint8_t Position_KP,uint8_t Position_KI,  RMD_X_V3_State * state);
void RMD_X_V3_RAW_motion_mode_control(CAN_HandleTypeDef* hcan, uint32_t address ,uint16_t p_des, uint16_t v_des, uint16_t KP_value, uint16_t KD_value, uint16_t t_ff_value, RMD_X_V3_State * state);
void RMD_X_V3_RAW_command_read_pid_parameter(CAN_HandleTypeDef* hcan, uint32_t address ,RMD_X_V3_State * state);
void RMD_X_V3_RAW_command_read_single_turn_encoder(CAN_HandleTypeDef* hcan, uint32_t address ,RMD_X_V3_State * state);
void RMD_X_V3_RAW_command_read_multi_turn_angle(CAN_HandleTypeDef* hcan, uint32_t address ,RMD_X_V3_State * state);
void RMD_X_V3_RAW_command_read_single_turn_angle(CAN_HandleTypeDef* hcan, uint32_t address ,RMD_X_V3_State * state);
void RMD_X_V3_RAW_command_read_motor_status1_error_flag(CAN_HandleTypeDef* hcan, uint32_t address ,RMD_X_V3_State * state);
void RMD_X_V3_RAW_command_read_motor_status2(CAN_HandleTypeDef* hcan, uint32_t address ,RMD_X_V3_State * state);
void RMD_X_V3_RAW_command_read_motor_status3(CAN_HandleTypeDef* hcan, uint32_t address ,RMD_X_V3_State * state);
void RMD_X_V3_RAW_command_motor_shutdown(CAN_HandleTypeDef* hcan, uint32_t address ,RMD_X_V3_State * state);
void RMD_X_V3_RAW_command_torque_closed_loop_control(CAN_HandleTypeDef* hcan, uint32_t address ,int16_t iqControl, RMD_X_V3_State * state);
void RMD_X_V3_RAW_command_speed_closed_loop_control(CAN_HandleTypeDef* hcan, uint32_t address ,uint32_t speedControl, RMD_X_V3_State * state);
void RMD_X_V3_RAW_command_absolute_position_closed_loop_control(CAN_HandleTypeDef* hcan, uint32_t address ,int32_t angleControl, uint16_t maxSpeed, RMD_X_V3_State * state);
void RMD_X_V3_RAW_command_single_turn_position_control(CAN_HandleTypeDef* hcan, uint32_t address, uint16_t angleControl, uint8_t spinDirection, uint16_t maxSpeed, RMD_X_V3_State * state);
void RMD_X_V3_RAW_command_incremental_position_closed_loop_control(CAN_HandleTypeDef* hcan, uint32_t address , int32_t angleControl, uint16_t maxSpeed,RMD_X_V3_State * state);
void RMD_X_V3_RAW_command_motor_power_acquisition(CAN_HandleTypeDef* hcan, uint32_t address ,RMD_X_V3_State * state);
void RMD_X_V3_RAW_command_system_brake_release_state(CAN_HandleTypeDef* hcan, uint32_t address ,RMD_X_V3_State * state);
void RMD_X_V3_RAW_command_system_brake_lock(CAN_HandleTypeDef* hcan, uint32_t address ,RMD_X_V3_State * state);
void RMD_X_V3_RAW_deserialize(RMD_X_V3_Message* message, RMD_X_V3_State_RAW* state_raw);
void RMD_X_V3_RAW_system_reset_command(CAN_HandleTypeDef* hcan, uint32_t address ,RMD_X_V3_State * state);
void RMD_X_V3_RAW_write_encoder_multi_turn_value_to_ROM_as_zero_motor_command(CAN_HandleTypeDef* hcan, uint32_t address ,RMD_X_V3_State * state);

//REPLY V3
void RMD_X_V3_RAW_reply_read_pid_parameter(RMD_X_V3_Message* message, RMD_X_V3_State_RAW* state_raw);
void RMD_X_V3_RAW_reply_read_single_turn_encoder(RMD_X_V3_Message* message, RMD_X_V3_State_RAW* state_raw);
void RMD_X_V3_RAW_reply_read_multi_turn_angle(RMD_X_V3_Message* message, RMD_X_V3_State_RAW* state_raw);
void RMD_X_V3_RAW_reply_read_single_turn_angle(RMD_X_V3_Message* message, RMD_X_V3_State_RAW* state_raw);
void RMD_X_V3_RAW_reply_read_motor_status1_error_flag(RMD_X_V3_Message* message, RMD_X_V3_State_RAW* state_raw);
void RMD_X_V3_RAW_reply_read_motor_status2(RMD_X_V3_Message* message, RMD_X_V3_State_RAW* state_raw);
void RMD_X_V3_RAW_reply_read_motor_status3(RMD_X_V3_Message* message, RMD_X_V3_State_RAW* state_raw);
void RMD_X_V3_RAW_reply_single_turn_position_control(RMD_X_V3_Message* message, RMD_X_V3_State_RAW* state_raw);
void RMD_X_V3_RAW_reply_motor_power_acquisition(RMD_X_V3_Message* message, RMD_X_V3_State_RAW* state_raw);
void RMD_X_V3_RAW_reply_motion_mode_control(RMD_X_V3_Message* message, RMD_X_V3_State_RAW* state_raw);
#endif

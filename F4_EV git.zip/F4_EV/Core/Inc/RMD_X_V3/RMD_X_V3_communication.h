/*
 * RMD_X_communication.h
 *
 *  Created on: March 2, 2023
 *      Author: Davide
 */

#ifndef INC_RMD_X_V3_RMD_X_COMMUNICATION_H_
#define INC_RMD_X_V3_RMD_X_COMMUNICATION_H_

#include "main.h"
#include "RMD_X_V3/RMD_X_V3_Controller.h"



void RMD_X_V3_CAN_receive_state(uint8_t* data_in, RMD_X_V3_State* state, RMD_X_V3_State_RAW* state_raw);
void RMD_X_V3_CAN_receive_motion_mode_state(uint8_t* data_in, RMD_X_V3_State* state, RMD_X_V3_State_RAW* state_raw);
void RMD_X_V3_Send_Data(CAN_HandleTypeDef* hcan, uint32_t address, RMD_X_V3_Message* message,RMD_X_V3_State * state);
void RMD_X_V3_Receive_Data(uint8_t* data_in, RMD_X_V3_State* state );

#endif /* INC_RMD_X_RMD_X_COMMUNICATION_H_ */

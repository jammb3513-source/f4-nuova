#pragma once
#include <STERZO/epos4_config.h>

EPOS4_Result EPOS4_BootAndEnable(CAN_HandleTypeDef *hcan); //gestione delle due macchine a stati
void EPOS4_Init();
void EPOS4_Enable();

void EPOS4_Send_TargetPosition(void); //callback timer con invio RPDO
void EPOS4_SendSYNC(void);

EPOS4_Result EPOS4_SetTargetCounts(int32_t counts);
EPOS4_Result EPOS4_SetTargetAngleDeg(float angle_deg);
EPOS4_Result EPOS4_STEP();

void EPOS4_OnCanRx(const CAN_RxHeaderTypeDef* hdr, const uint8_t* data); // callback CAN
const EPOS4_State* EPOS4_GetState(void);
void parse_status(uint16_t sw);

EPOS4_Result EPOS4_QuickStop(void);
EPOS4_Result EPOS4_FaultReset(void);

// --- Utility SDO  ---
EPOS4_Result EPOS4_SDO_ReadStatusword(uint16_t* sw);
EPOS4_Result EPOS4_SDO_ReadModesDisplay(uint8_t* mode_disp);
EPOS4_Result EPOS4_SDO_ReadPositionActual(int32_t* pos);
EPOS4_Result EPOS4_SDO_ReadVelocityActual(int32_t* vel);
EPOS4_Result EPOS4_SDO_ReadTorqueActual(int16_t* tq);
EPOS4_Result EPOS4_SDO_ReadErrorRegister(uint8_t* err_reg);  // 0x1001
EPOS4_Result EPOS4_SDO_ReadErrorCode(uint16_t* err_code);    // 0x603F
EPOS4_Result EPOS4_SDO_WriteHeartbeatTime(uint16_t ms);      // 0x1017:00
EPOS4_Result EPOS4_SDO_SetMode(EPOS4_Mode mode);             // 0x6060:00

EPOS4_Result sdo_write_u16(uint16_t idx, uint8_t sub, uint16_t v);

void provaa(uint16_t cw);



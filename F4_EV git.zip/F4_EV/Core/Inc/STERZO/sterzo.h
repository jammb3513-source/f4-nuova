/*
 * sterzo.h
 *
 *  Created on: Feb 21, 2022
 *      Author: chip & ciop
 */

#ifndef INC_STERZO_STERZO_H_
#define INC_STERZO_STERZO_H_

#include "main.h" // serve per le variabili

#define STEERING_STATE_UNAVAILABLE   0  //usato in STEERING_Task che non viene mai chiamata
#define STEERING_STATE_AVAILABLE     1  // usato in sterzo_check() -> continuos_monitoring()
#define STERZO_FAILURE_CHECK         2  // usato in sterzo_check() -> continuos_monitoring()


extern uint8_t primo_messaggio_sterzo;
extern uint8_t flag_sterzo;


typedef struct STERZO{
	uint8_t state;
	float angle;
    uint8_t sa; //steering actuator
    uint8_t stato_can;
    uint8_t potenziometro_sterzo;
    uint32_t last_message;
    int16_t offset;
}STERZO;
extern STERZO steering;


#endif /* INC_STERZO_STERZO_H_ */

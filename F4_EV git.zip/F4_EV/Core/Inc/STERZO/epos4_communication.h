#pragma once

#include <string.h>
#include "stm32f4xx_hal.h"
#include <stdint.h>
#include <STERZO/epos4_config.h>



typedef struct {
  CAN_HandleTypeDef* hcan;
  uint8_t  node_id;
} EPOS4_CanCtx;

extern EPOS4_CanCtx _epos4_can;

static inline uint16_t COB_ID_NMT(void)   { return 0x000; }
static inline uint16_t COB_ID_SYNC(void)  { return 0x080; }
static inline uint16_t COB_ID_EMCY(uint8_t nid){ return 0x080 + nid; }
static inline uint16_t COB_ID_TPDO1(uint8_t nid){ return 0x1A0; }
static inline uint16_t COB_ID_RPDO1(uint8_t nid){ return 0x200 + nid; }
static inline uint16_t COB_ID_SDO_TX(uint8_t nid){ return 0x580 + nid; } // server->client
static inline uint16_t COB_ID_SDO_RX(uint8_t nid){ return 0x600 + nid; } // client->server
static inline uint16_t COB_ID_HB(uint8_t nid)   { return 0x700 + nid; }

HAL_StatusTypeDef EPOS4_CAN_SendStd(uint16_t id, const uint8_t* data, uint8_t len);
void EPOS4_CAN_SendNMT(uint8_t cmd, uint8_t node_id);
void EPOS4_SendSYNC(void);



#define OD_CONTROLWORD              0x6040
#define OD_STATUSWORD               0x6041
#define OD_MODES_OF_OPERATION       0x6060
#define OD_MODES_DISPLAY            0x6061
#define OD_TARGET_POSITION          0x607A
#define OD_POSITION_ACTUAL          0x6064
#define OD_VELOCITY_ACTUAL          0x606C
#define OD_TORQUE_ACTUAL            0x6077

// PDO mapping + comm params
#define OD_RPDO1_COMM               0x1400
#define OD_RPDO1_MAPPING            0x1600
#define OD_TPDO1_COMM               0x1800
#define OD_TPDO1_MAPPING            0x1A00

// Network management / error control
#define OD_HEARTBEAT_TIME           0x1017

// SDO sizes helper
#define MAP_U8(idx,sub)   (((uint32_t)(idx) << 16) | ((uint32_t)(sub) << 8) | 8)
#define MAP_U16(idx,sub)  (((uint32_t)(idx) << 16) | ((uint32_t)(sub) << 8) | 16)
#define MAP_U32(idx,sub)  (((uint32_t)(idx) << 16) | ((uint32_t)(sub) << 8) | 32)

#define OD_HOME_OFFSET              0x607C
#define OD_HOMING_METHOD            0x6098
#define OD_HOMING_SPEEDS            0x6099   // 0x01 = speed for switch search, 0x02 = speed for index search
#define OD_HOMING_ACCEL             0x609A   // 32 bit


EPOS4_Result EPOS4_PDO_Map_Minimal_CSP(uint8_t node_id, uint16_t inhibit_us);
EPOS4_Result EPOS4_PDO_Send_RPDO1_Control_Target(uint16_t controlword, int32_t target_counts);



typedef struct {
  uint8_t  busy;
  uint8_t  is_read;
  uint16_t index;
  uint8_t  sub;
  uint8_t  size;     // 1/2/4
  uint32_t val;      // per write o read result
  uint16_t timeout_ms, elapsed_ms;
} EPOS4_SdoXfer;

extern EPOS4_SdoXfer _sdo;

EPOS4_Result EPOS4_SDO_Write(uint16_t idx, uint8_t sub, uint32_t val, uint8_t size);
EPOS4_Result EPOS4_SDO_Read (uint16_t idx, uint8_t sub, uint32_t* out, uint8_t size);
void EPOS4_SDO_OnRx(const CAN_RxHeaderTypeDef* hdr, const uint8_t* d);
void EPOS4_SDO_Tick1ms(void);


EPOS4_Result sdo_write_u8(uint16_t idx, uint8_t sub, uint8_t v);
EPOS4_Result sdo_write_u16(uint16_t idx, uint8_t sub, uint16_t v);
EPOS4_Result sdo_write_blocking_u16(uint16_t idx, uint8_t sub, uint16_t v, uint16_t to_ms);

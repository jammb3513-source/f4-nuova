/*
 * AS.c
 *
 *  Created on: Feb 19, 2022
 *      Author: chip & ciop
 */
#include "tim.h"
#include "AS/AS.h"
#include "ASSI/ASSI.h"
#include "CAN/CAN_communication.h"
#include "EBS/ebs.h"
#include "FRENO/freno.h"
#include "ADC/ADS1115.h"
#include "TS/ts.h"
uint8_t primo_messaggio_AI=0;
Dati_AS dati_as;

int five_delay;//5s dello start
int delay_timer_started=0;

//#define BYPASSTS 1
//#define BYPASSSB 1
//#define BYPASSR2D 1
//int stato_ASms=0;


//FUNZIONE 22/23
void AS_setup_dati(){

	dati_as.asms=HAL_GPIO_ReadPin(ASMS_IN_GPIO_Port, ASMS_IN_Pin); //LETTURA ASMS
	dati_as.sdc = HAL_GPIO_ReadPin(SDC_READ_GPIO_Port, SDC_READ_Pin); //LETTURA SDC

#ifdef BYPASSR2D
	dati_as.r2d = res.go && !res.enable_go; //Mantengo premuto il GO
#endif

	//dati_as.speed = (fonicata.ant_dx + fonicata.ant_sx)/2;//(vehicle_status.speed_actual);
}


void AS_init(){
	dati_as.timer_Delay=0;
	AS_task();
	delay_timer_started = OFF;
	five_delay = OFF;
}


int Driverless_ON(){
	#ifdef	BYPASSTS
			return (riferimenti_ia.ami>=0 && riferimenti_ia.ami <= 6 && dati_as.asms==ASMS_ON  && dati_as.asb_check==ASB_ON);
	#endif


	#ifndef	BYPASSTS
			return (riferimenti_ia.ami>=1 && riferimenti_ia.ami <= 6 && dati_as.asms==ASMS_ON  && dati_as.asb_check==ASB_ON);
	#endif
}


void AS_task(){

	AS_setup_dati();

	if(dati_as.stato==AS_STATE_DRIVING && dati_as.asms==OFF){
		AS_emergency();
		HAL_Delay(100);
	}

	if((dati_as.asms == OFF || ebs.primo_check == 0) && dati_as.sound == OFF){
		AS_off();
	}else if(dati_as.stato == AS_STATE_FINISHED && (brakesys_adc.press_ebs < 7 || res.enable_go == 0) && res.emergenza != 0){
		AS_off();
	}else if(ebs.state>=EBS_STATE_ACTIVATED && dati_as.stato != AS_STATE_OFF){
		if( riferimenti_ia.mission_finished == 1){
			AS_finished();
		} else{
			AS_emergency();
		}
	}
	else if(ebs.state!=EBS_STATE_ACTIVATED && dati_as.sound==OFF){

		if(Driverless_ON()){

				if(dati_as.stato<= AS_STATE_READY){
					EPOS4_Init();
					dati_as.stato=AS_STATE_CC;
				}
				if(dati_as.r2d==R2D_ON){
					EPOS4_Enable();
					AS_driving();
				}else{
#ifdef BYPASSSB
					AS_ready();
#else
					if(brake.sb==SB_ENGAGED)
						AS_ready();
					else{
						AS_off();
						dati_as.stato=AS_STATE_CC;
					}
#endif

				}
		}
	}else if(dati_as.stato!=AS_STATE_EMERGENCY){
		AS_off();
	}
}


void AS_finished(){
	dati_as.stato=AS_STATE_FINISHED;
	ASSI_set_flashingBuzzer(ASSI_blue_continuous);
	primo_messaggio_AI=0;
}


void AS_driving(){
	dati_as.stato=AS_STATE_DRIVING;
	ASSI_set_flashingBuzzer(ASSI_yellow_flashing);
	five_delay=OFF;
}


// TODO funzione da reworkare
void AS_ready(){

	//if(dati_as.stato != AS_METTI_MARCIA)   // TODO combustion dependancy
	if(1)
		dati_as.stato=AS_STATE_READY;

	ASSI_set_flashingBuzzer(ASSI_yellow_continuous);
	AS_start_delay_count();

	if(five_delay==ON) { //quindi se sono passati 5 secondi da quando sono in ready, posso partire
		if(res.enable_go==ON && res.go==ON){
		   //dati_as.stato=AS_METTI_MARCIA;   // TODO combustion dependancy
		}
	}
}


inline void AS_start_delay_count() {
	 if(delay_timer_started == OFF && five_delay == OFF)
		HAL_TIM_Base_Start_IT(&htim6);
}


void AS_off(){
	ASSI_off();
	dati_as.stato = AS_STATE_OFF;
	primo_messaggio_AI=0;
}

void AS_emergency(){
	if(dati_as.stato != AS_STATE_EMERGENCY){
		dati_as.stato = AS_STATE_EMERGENCY;
		ASSI_set_flashingBuzzer(ASSI_blue_flashing);
		five_delay=OFF; //flag
		AS_start_delay_count();
		dati_as.sound=ON;
		primo_messaggio_AI=0;

	}
}

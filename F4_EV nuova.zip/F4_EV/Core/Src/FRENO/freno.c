/*
 * freno.c
 *
 *  Created on: 21 feb 2022
 *      Author: chip & ciop
 */
#include "FRENO/freno.h"
#include "RMD_X_V3/RMD_X_V3_Communication.h"
#include "RMD_X_V3/RMD_X_V3_Controller.h"
#include "RMD_X_V3/RMD_X_V3_Command.h"
uint8_t primo_messaggio_freno;  // TODO primo_messaggio_freno viene definito dagli RMD nella callback CAN
// senza il codice degli RMD questa variabile non commuta mai a 1 e non entra nel check (check.c riga 29)

FRENO brake;
RMD_X_V3_State_RAW state_raw_freno;
RMD_X_V3_State RMD_freno;

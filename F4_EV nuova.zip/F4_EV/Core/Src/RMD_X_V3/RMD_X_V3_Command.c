/*
 * RMD_X_command.c
 *
 *  Created on: 02 March 2023
 *      Author: Davide
 */
#include "RMD_X_V3/RMD_X_V3_command.h"
#include "map.h"
#include "settings.h"

void RMD_X_V3_torque_closed_loop_control(CAN_HandleTypeDef* hcan, uint32_t address ,float ampere, RMD_X_V3_State * state){
	int16_t torqueCurrentControlValue = (int16_t) map(ampere, -32, 32, -2000, 2000);
	RMD_X_V3_RAW_command_torque_closed_loop_control(hcan,address,torqueCurrentControlValue,state);
}
void RMD_X_V3_speed_closed_loop_control(CAN_HandleTypeDef* hcan, uint32_t address ,uint8_t reduction_ratio, float rpm, RMD_X_V3_State * state){
	float dps = rpm * RPM_TO_DPS;
	uint32_t speedControl = (uint32_t) (dps * (reduction_ratio * 100));
	RMD_X_V3_RAW_command_speed_closed_loop_control(hcan,address,speedControl,state);
}
void RMD_X_V3_absolute_position_closed_loop_control(CAN_HandleTypeDef* hcan, uint32_t address ,uint8_t reduction_ratio, float limitRpm, float positionControlGradi, RMD_X_V3_State * state){
	uint16_t speedLimited = (uint16_t) ((limitRpm * reduction_ratio) * RPM_TO_DPS);
	int32_t positionControl = (int32_t) (positionControlGradi * (reduction_ratio*100));
	RMD_X_V3_RAW_command_absolute_position_closed_loop_control(hcan,address,positionControl,speedLimited,state);
}
void RMD_X_V3_single_turn_position_control(CAN_HandleTypeDef* hcan, uint32_t address ,uint8_t reduction_ratio, int spinDirection, float limitRpm, float positionControlGradi,RMD_X_V3_State * state){
	uint8_t Direction = (uint8_t) (spinDirection & 0x01);
	uint16_t speedLimited = (uint16_t) ((limitRpm * reduction_ratio) * RPM_TO_DPS);
	uint32_t positionControl = (uint32_t) (positionControlGradi * (reduction_ratio * 100));
	RMD_X_V3_RAW_command_single_turn_position_control(hcan, address, Direction, speedLimited, positionControl,state);
}
void RMD_X_V3_motion_mode_control(CAN_HandleTypeDef* hcan, uint32_t address ,float pos_gradi, float speed, float KP, float KD, float t_ff, RMD_X_V3_State * state){
	//Check input value (pag. 90 RMD-X protocol)
	float pos_gradi_val = pos_gradi;
	float speed_val = speed;
	float KP_val = 0;
	float KD_val = 0;
	float t_ff_val = t_ff;
	/*Posizione*/
//
//	if(pos_gradi>12.5*180/3.14) pos_gradi_val = ;
//	else if(pos_gradi<-12.5) pos_gradi_val = -12.5;
//	else pos_gradi_val = pos_gradi;
//	/*Speed*/
//	if(speed>45) speed_val = 45;
//	else if(speed<-45) speed_val = -45;
//	else speed_val = speed;
//	/*t_ff*/
//	if(t_ff>24) t_ff_val = 24;
//	else if(t_ff<-24) t_ff_val = -24;
//	else t_ff_val = t_ff;
//	/*KP*/
	if(KP>500) KP_val = 500;
	else if(KP<0) KP_val = 0;
	else KP_val = KP;
//	/*KD*/
	if(KD>5) KD_val = 5;
	else if(KD<0) KD_val = 0;
	else KD_val = KD;
//	/**/

	/**/
	uint16_t p_des = (uint16_t) ((((pos_gradi_val * 3.14)*0.0056)+12.5)*(65535*0.04));
	uint16_t v_des = 0;//(uint16_t) ((speed_val+45)*(4095*0.011)); //speed è in Rad/s
	uint16_t KP_value = (uint16_t) (KP_val * (4095*0.002));
	uint16_t KD_value = (uint16_t) (KD_val * (4095*0.2));
	uint16_t t_ff_value = 0;//(uint16_t) ((t_ff_val + 24) * (4095*0.0208));
	RMD_X_V3_RAW_motion_mode_control(hcan, address ,p_des, v_des,KP_value,KD_value,t_ff_value, state);
}
void RMD_X_V3_update_state(RMD_X_V3_State* state, uint8_t reduction_ratio, RMD_X_V3_State_RAW* state_raw ){
	// >> ANGOLO <<
			state->angle = ((float) state_raw->motorAngle) / (STERZO_COMPENSAZIONE_VAL_RID*reduction_ratio*100);
	//		RMD_X.singleAngle = (float) state_raw->singleAngle / 100;

		// >> TEMPERATURA E VOLTAGGIO
			state->motorTemperature = state_raw->motorTemperature;
			state->voltage = ((float) state_raw->voltage) / 10;

		// >> ERRORI <<
			state->errorLowVoltage = RMD_X_V3_RAW_status_low_voltage_protection(state_raw);
			state->errorOverTemperature = RMD_X_V3_RAW_status_over_temperature_protection(state_raw);

		// >> COPPIA <<
			float torqueCurrent = (float) state_raw->torqueCurrent;
			state->torqueCurrent = map(torqueCurrent, -2048, 2048, -33, 33); //Ampere [-33, 33]

		// >> VELOCITA' <<
			state->speedDPS = state_raw->speed / (reduction_ratio); //Gradi al secondo
			float speed = (float) state->speedDPS;
			state->speedRPM = (speed * DPS_TO_RPM); //Rotazioni al minuto

		//>> PID <<
			state->CurrKI = state_raw->CurrKI;
			state->CurrKP = state_raw->CurrKP;
			state->PosKI = state_raw->PosKI;
			state->PosKP = state_raw->PosKP;
			state->SpeedKI = state_raw->SpeedKI;
			state->SpeedKP = state_raw->SpeedKP;

		//>>Motion Mode converted value <<
			state->CANID = state_raw->CANID;
			state->motion_position = (float)((180/3.14) * (((state_raw->p_des)*25/65535)-12.5));
			state->motion_speed = (float) (((state_raw->v_des)*90/4095)-45);
			state->motion_torque = (float) (((state_raw->t_ff)*48/4095)-24);


}

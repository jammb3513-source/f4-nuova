/*
 * RMD_X_V3_Controller.c
 *
 *  Created on: 27 feb 2023
 *      Author: Davide
 */

#include "RMD_X_V3/RMD_X_V3_communication.h"
#include "string.h"

inline void RMD_X_V3_RAW_set_replyPending(RMD_X_V3_State * state) {state->replyPending = 1;}
inline void RMD_X_V3_RAW_clear_replyPending(RMD_X_V3_State * state) {state->replyPending = 0;}

//Get dello status

int RMD_X_V3_RAW_status_low_voltage_protection( RMD_X_V3_State_RAW* state_raw) {return (state_raw->errorState & 0x01);}
int RMD_X_V3_RAW_status_over_temperature_protection( RMD_X_V3_State_RAW* state_raw) {return ((state_raw->errorState & 0x08) >> 3);}

void RMD_X_V3_RAW_command_read_pid_parameter(CAN_HandleTypeDef* hcan, uint32_t address ,RMD_X_V3_State * state){
	RMD_X_V3_Message message = {0};

	message.commandByte = READ_PID_PARAMETER;
	RMD_X_V3_Send_Data(hcan, address,  &message,state);

}
void RMD_X_V3_RAW_command_write_pid_parameter_to_rom(CAN_HandleTypeDef* hcan, uint32_t address ,uint8_t Current_KP, uint8_t Current_KI, uint8_t Speed_KP, uint8_t Speed_KI, uint8_t Position_KP,uint8_t Position_KI,  RMD_X_V3_State * state){
	RMD_X_V3_Message message = {0};

	message.commandByte = WRITE_PID_PARAMETER_TO_ROM;
	message.data2 = Current_KP;
	message.data3 = Current_KI;
	message.data4 = Speed_KP;
	message.data5 = Speed_KI;
	message.data6 = Position_KP;
	message.data7 = Position_KI;
	RMD_X_V3_Send_Data(hcan, address, &message,state);

}
void RMD_X_V3_RAW_motion_mode_control(CAN_HandleTypeDef* hcan, uint32_t address ,uint16_t p_des, uint16_t v_des, uint16_t KP_value, uint16_t KD_value, uint16_t t_ff_value, RMD_X_V3_State * state){
	RMD_X_V3_Message message = {0};

	message.commandByte = (uint8_t)(p_des>>8); //p_des HIGH [15-8]
	message.data1 = (uint8_t) (p_des); 		   //p_des LOW  [7-0]
	message.data2 = (uint8_t) (v_des>>4);	   //v_des [11-4]
	message.data3 = (uint8_t) ( (KP_value>>4) & (0xF0) ) | (v_des & 0x0F); //KP[11-8] | v_des[3-0]
	message.data4 = (uint8_t) KP_value;									   //KP[7-0]
	message.data5 = (uint8_t) (KD_value>>4);									//KD[11-4]
	message.data6 = (uint8_t) ( (t_ff_value>>4) & (0xF0) ) | (KD_value & 0x0F); //t_ff[11-8] | KD[3-0]
	message.data7 = (uint8_t) t_ff_value;										//t_ff[7-0]
	RMD_X_V3_Send_Data(hcan, address, &message,state);
}
void RMD_X_V3_RAW_command_read_single_turn_encoder(CAN_HandleTypeDef* hcan, uint32_t address ,RMD_X_V3_State * state){
	RMD_X_V3_Message message = {0};

	message.commandByte = READ_SINGLE_TURN_ENCODER;
	RMD_X_V3_Send_Data(hcan, address,  &message,state);

}
void RMD_X_V3_RAW_command_read_multi_turn_angle(CAN_HandleTypeDef* hcan, uint32_t address ,RMD_X_V3_State * state){
	RMD_X_V3_Message message = {0};

	message.commandByte = READ_MULTI_TURN_ANGLE;
	RMD_X_V3_Send_Data(hcan, address,  &message,state);

}
void RMD_X_V3_RAW_command_read_single_turn_angle(CAN_HandleTypeDef* hcan, uint32_t address ,RMD_X_V3_State * state){
	RMD_X_V3_Message message = {0};

	message.commandByte = READ_SINGLE_TURN_ANGLE;
	RMD_X_V3_Send_Data(hcan, address,  &message,state);

}
void RMD_X_V3_RAW_command_read_motor_status1_error_flag(CAN_HandleTypeDef* hcan, uint32_t address ,RMD_X_V3_State * state){
	RMD_X_V3_Message message = {0};

	message.commandByte = READ_MOTOR_STATUS1_ERROR_FLAG;
	RMD_X_V3_Send_Data(hcan, address,  &message,state);

}
void RMD_X_V3_RAW_command_read_motor_status2(CAN_HandleTypeDef* hcan, uint32_t address ,RMD_X_V3_State * state){
	RMD_X_V3_Message message = {0};

	message.commandByte = READ_MOTOR_STATUS2;
	RMD_X_V3_Send_Data(hcan, address,  &message,state);

}
void RMD_X_V3_RAW_command_read_motor_status3(CAN_HandleTypeDef* hcan, uint32_t address ,RMD_X_V3_State * state){
	RMD_X_V3_Message message = {0};

	message.commandByte = READ_MOTOR_STATUS3;
	RMD_X_V3_Send_Data(hcan, address,  &message,state);

}
void RMD_X_V3_RAW_command_motor_shutdown(CAN_HandleTypeDef* hcan, uint32_t address ,RMD_X_V3_State * state){
	RMD_X_V3_Message message = {0};

	message.commandByte = MOTOR_SHUTDOWN;
	RMD_X_V3_Send_Data(hcan, address,  &message,state);

}
void RMD_X_V3_RAW_command_torque_closed_loop_control(CAN_HandleTypeDef* hcan, uint32_t address ,int16_t iqControl, RMD_X_V3_State * state){
	RMD_X_V3_Message message = {0};

	message.commandByte = TORQUE_CLOSED_LOOP_CONTROL;
	message.data4 = (uint8_t) iqControl;
	message.data5 = (uint8_t) (iqControl >> 8);
	RMD_X_V3_Send_Data(hcan, address,  &message,state);

}
void RMD_X_V3_RAW_command_speed_closed_loop_control(CAN_HandleTypeDef* hcan, uint32_t address ,uint32_t speedControl, RMD_X_V3_State * state){
	RMD_X_V3_Message message = {0};

	message.commandByte = SPEED_CLOSED_LOOP_CONTROL;
	message.data4 = (uint8_t) speedControl;
	message.data5 = (uint8_t) (speedControl >> 8);
	message.data6 = (uint8_t) (speedControl >> 16);
	message.data7 = (uint8_t) (speedControl >> 24);
	RMD_X_V3_Send_Data(hcan, address,  &message,state);

}
void RMD_X_V3_RAW_command_absolute_position_closed_loop_control(CAN_HandleTypeDef* hcan, uint32_t address ,int32_t angleControl, uint16_t maxSpeed, RMD_X_V3_State * state){
	RMD_X_V3_Message message = {0};

	message.commandByte = ABSOLUTE_POSITIION_CLOSED_LOOP_CONTROL;
	message.data2 = (uint8_t) maxSpeed;
	message.data3 = (uint8_t) (maxSpeed >> 8);
	message.data4 = (uint8_t) angleControl;
	message.data5 = (uint8_t) (angleControl >> 8);
	message.data6 = (uint8_t) (angleControl >> 16);
	message.data7 = (uint8_t) (angleControl >> 24);
	RMD_X_V3_Send_Data(hcan, address,  &message,state);

}
void RMD_X_V3_RAW_command_single_turn_position_control(CAN_HandleTypeDef* hcan, uint32_t address, uint16_t angleControl, uint8_t spinDirection, uint16_t maxSpeed, RMD_X_V3_State * state){
	RMD_X_V3_Message message = {0};

	message.commandByte = SINGLE_TURN_POSITION_CONTROL;
	message.data1 = spinDirection;
	message.data2 = (uint8_t) maxSpeed;
	message.data3 = (uint8_t) (maxSpeed >> 8);
	message.data4 = (uint8_t) angleControl;
	message.data5 = (uint8_t) (angleControl >> 8);
	RMD_X_V3_Send_Data(hcan, address,  &message,state);

}
void RMD_X_V3_RAW_command_incremental_position_closed_loop_control(CAN_HandleTypeDef* hcan, uint32_t address , int32_t angleControl, uint16_t maxSpeed,RMD_X_V3_State * state){
	RMD_X_V3_Message message = {0};

	message.commandByte = INCREMENTAL_POSITION_CLOSED_LOOP_CONTROL;
	message.data2 = (uint8_t) maxSpeed;
	message.data3 = (uint8_t) (maxSpeed >> 8);
	message.data4 = (uint8_t) angleControl;
	message.data5 = (uint8_t) (angleControl >> 8);
	message.data6 = (uint8_t) (angleControl >> 16);
	message.data7 = (uint8_t) (angleControl >> 24);
	RMD_X_V3_Send_Data(hcan, address,  &message,state);

}
void RMD_X_V3_RAW_command_motor_power_acquisition(CAN_HandleTypeDef* hcan, uint32_t address ,RMD_X_V3_State * state){
	RMD_X_V3_Message message = {0};

	message.commandByte = MOTOR_POWER_ACQUISITION;
	RMD_X_V3_Send_Data(hcan, address,  &message,state);

}
void RMD_X_V3_RAW_command_system_brake_release_state(CAN_HandleTypeDef* hcan, uint32_t address ,RMD_X_V3_State * state){
	RMD_X_V3_Message message = {0};

	message.commandByte = SYSTEM_BRAKE_RELEASE;
	RMD_X_V3_Send_Data(hcan, address,  &message,state);

}
void RMD_X_V3_RAW_command_system_brake_lock(CAN_HandleTypeDef* hcan, uint32_t address ,RMD_X_V3_State * state){
	RMD_X_V3_Message message = {0};

	message.commandByte = SYSTEM_BRAKE_LOCK;
	RMD_X_V3_Send_Data(hcan, address,  &message,state);

}
void RMD_X_V3_RAW_reply_read_pid_parameter(RMD_X_V3_Message* message, RMD_X_V3_State_RAW* state_raw){
	state_raw -> CurrKP = message->data2;
	state_raw -> CurrKI = message->data3;
	state_raw -> SpeedKP = message->data4;
	state_raw -> SpeedKI = message->data5;
	state_raw -> PosKP = message->data6;
	state_raw -> PosKI = message->data7;
}
void RMD_X_V3_RAW_reply_read_single_turn_encoder(RMD_X_V3_Message* message, RMD_X_V3_State_RAW* state_raw){
	//state_raw->encoderPosition = ((uint16_t) message->data2 << 8) | (uint16_t) message->data1;
	state_raw->encoderPosition = ((uint16_t) message->data3 << 8) | (uint16_t) message->data2;
	//state_raw->encoderOriginalPosition = ((uint16_t) message->data4 << 8) | (uint16_t) message->data3;
	state_raw->encoderOriginalPosition = ((uint16_t) message->data5 << 8) | (uint16_t) message->data4;

}
void RMD_X_V3_RAW_reply_read_multi_turn_angle(RMD_X_V3_Message* message, RMD_X_V3_State_RAW* state_raw){
	state_raw -> motorAngle = (uint32_t) (message->data7 << 24) | (uint32_t) (message->data6 << 16) |(uint32_t) (message->data5 << 8) |(uint32_t) (message->data4);
}
void RMD_X_V3_RAW_reply_read_single_turn_angle(RMD_X_V3_Message* message, RMD_X_V3_State_RAW* state_raw){
	state_raw -> circleAngle = (uint16_t) (message->data7 << 8)|(uint16_t) (message->data6);
}
void RMD_X_V3_RAW_reply_read_motor_status1_error_flag(RMD_X_V3_Message* message, RMD_X_V3_State_RAW* state_raw){
	state_raw -> motorTemperature = message->data1;
	state_raw -> BrakeReleaseCommand = message->data3;
	state_raw -> voltage = (uint16_t) (message->data5 << 8) | (uint16_t) (message->data4);
	state_raw -> errorState = (uint16_t) (message->data7 << 8) | (uint16_t) (message->data6);
}
void RMD_X_V3_RAW_reply_read_motor_status2(RMD_X_V3_Message* message, RMD_X_V3_State_RAW* state_raw){
	state_raw -> motorTemperature = message->data1;
	state_raw -> torqueCurrent = (uint16_t) (message->data3 << 8) | (uint16_t) (message->data2);
	state_raw -> speed =  (uint16_t) (message->data5 << 8) | (uint16_t) (message->data4);
	state_raw -> motorAngle = (uint32_t) (message->data7 << 8) | (uint32_t) (message->data6);
}
void RMD_X_V3_RAW_reply_read_motor_status3(RMD_X_V3_Message* message, RMD_X_V3_State_RAW* state_raw){

}

void RMD_X_V3_RAW_reply_single_turn_position_control(RMD_X_V3_Message* message, RMD_X_V3_State_RAW* state_raw){
	state_raw -> motorTemperature = message->data1;
	state_raw -> torqueCurrent = (uint16_t) (message->data3 << 8) | (uint16_t) (message->data2);
	state_raw -> speed =  (uint16_t) (message->data5 << 8) | (uint16_t) (message->data4);
	//state_raw->encoderPosition = ((uint16_t) message->data2 << 8) | (uint16_t) message->data1;
	state_raw->encoderPosition = ((uint16_t) message->data7 << 8) | (uint16_t) message->data6;

}
void RMD_X_V3_RAW_reply_motor_power_acquisition(RMD_X_V3_Message* message, RMD_X_V3_State_RAW* state_raw){
	state_raw->motorPower = ((uint16_t) message->data7 << 8) | (uint16_t) message->data6;
	//state_raw -> motorPower = message -> data7;
}

void RMD_X_V3_RAW_reply_motion_mode_control(RMD_X_V3_Message* message, RMD_X_V3_State_RAW* state_raw){
	state_raw->CANID = message->commandByte; //CANID 0-7
	state_raw->p_des = (uint16_t) (( ((uint16_t)(message->data1)) <<8) | (uint16_t)(message->data2)); //p_des 15-8 | p_des 7-0
	state_raw->v_des = (uint16_t) (( ((uint16_t)(message->data3)) <<4) | ((message->data4) & 0x0F) ); //v_des 4-11 | v_des 0-3
	state_raw->t_ff  = (uint16_t) (( (((uint16_t)(message->data4)) <<4) & 0x0F00) | (message->data5)); //t_ff 8-11 | t_ff 7-0
}

void RMD_X_V3_RAW_deserialize(RMD_X_V3_Message* message, RMD_X_V3_State_RAW* state_raw) {
	uint8_t addr = message->commandByte;
	switch (addr){
			case READ_PID_PARAMETER:
			case WRITE_PID_PARAMETER_TO_ROM:
				RMD_X_V3_RAW_reply_read_pid_parameter(message, state_raw);
				break;
			case READ_SINGLE_TURN_ENCODER:
				RMD_X_V3_RAW_reply_read_single_turn_encoder(message, state_raw);
				break;
			case READ_MULTI_TURN_ANGLE:
			//case ABSOLUTE_POSITIION_CLOSED_LOOP_CONTROL:
				RMD_X_V3_RAW_reply_read_multi_turn_angle(message, state_raw);
				break;
			case READ_SINGLE_TURN_ANGLE:
				RMD_X_V3_RAW_reply_read_single_turn_angle(message, state_raw);
				break;
			case READ_MOTOR_STATUS1_ERROR_FLAG:
				RMD_X_V3_RAW_reply_read_motor_status1_error_flag(message, state_raw);
				break;
			case READ_MOTOR_STATUS2:
			case TORQUE_CLOSED_LOOP_CONTROL:
			case SPEED_CLOSED_LOOP_CONTROL:
			case INCREMENTAL_POSITION_CLOSED_LOOP_CONTROL:
				RMD_X_V3_RAW_reply_read_motor_status2(message, state_raw);
				break;
			case READ_MOTOR_STATUS3:
				RMD_X_V3_RAW_reply_read_motor_status3(message, state_raw); //da fare?
				break;
			case SINGLE_TURN_POSITION_CONTROL:
				RMD_X_V3_RAW_reply_single_turn_position_control(message, state_raw);
				break;
			case MOTOR_POWER_ACQUISITION:
				RMD_X_V3_RAW_reply_motor_power_acquisition(message, state_raw);
				break;

	}

}

void RMD_X_V3_RAW_system_reset_command(CAN_HandleTypeDef* hcan, uint32_t address ,RMD_X_V3_State * state){
	RMD_X_V3_Message message = {0};

	message.commandByte = SYSTEM_RESET_COMMAND;
	RMD_X_V3_Send_Data(hcan, address,  &message,state);

}

void RMD_X_V3_RAW_write_encoder_multi_turn_value_to_ROM_as_zero_motor_command(CAN_HandleTypeDef* hcan, uint32_t address ,RMD_X_V3_State * state){
	RMD_X_V3_Message message = {0};

	message.commandByte = ENCODER_MULTI_TURN_VALUE_TO_ROM_ZERO_CMD;
	message.data4 = (uint8_t) 0x00;
	message.data5 = (uint8_t) 0x00;
	message.data6 = (uint8_t) 0x00;
	message.data7 = (uint8_t) 0x00;
	RMD_X_V3_Send_Data(hcan, address,  &message,state);

}


/*
 * ebs.c
 *
 *  Created on: Feb 20, 2022
 *      Author: chip & ciop
 *
 */
#include "AS/as.h"
#include "CAN/CAN_communication.h"
#include "CHECK/check.h"
#include "EBS/ebs.h"
#include "map.h"
#include "settings.h"
#include "ADC/ADS1115.h"
//#define BYPASSEBS	1
//#define CHECKRMD	1

EBS ebs;

uint8_t brake_emergency=0;


void EBS_task(){

	if(ebs.primo_check == OFF && dati_as.asms == 1){
		dati_as.asms=HAL_GPIO_ReadPin(ASMS_IN_GPIO_Port, ASMS_IN_Pin);
		EBS_stop_toggling_watchdog();//LETTURA ASMS
		if(dati_as.asms == SET)
			HAL_GPIO_WritePin(AS_CLOSE_GPIO_Port, AS_CLOSE_Pin, SET);
		else
			ebs.failureEBS = 0;

		ebs.state =  EBS_STATE_UNAVAILABLE;
	}

	dati_as.asms=HAL_GPIO_ReadPin(ASMS_IN_GPIO_Port, ASMS_IN_Pin); //LETTURA ASMS

	if(dati_as.asms == OFF){  //SEMPRE FATTA QUANDO ASMS = 0
		ebs.state = ebs.state & 0b00000011;
		HAL_GPIO_WritePin(AS_CLOSE_GPIO_Port, AS_CLOSE_Pin, RESET);
		if (ebs.primo_check==ON)
			EBS_start_toggling_watchdog();
	}


	if(ebs.primo_check==OFF && res.enable_go==0 && res.go==1 && ebs.failureEBS!=1) {
			EBS_check();
	}else if(ebs.primo_check==ON){
		ebs.sdc_ready=HAL_GPIO_ReadPin(SDC_READ_GPIO_Port, SDC_READ_Pin);
		if(ebs.sdc_ready == ON)
			ebs.state=EBS_STATE_ARMED;
		if(riferimenti_ia.ami >=0 && riferimenti_ia.ami <=22)  //PRIMA ERA >= 0 <=6
			HAL_GPIO_WritePin(AS_CLOSE_GPIO_Port, AS_CLOSE_Pin, RESET);
		else
			HAL_GPIO_WritePin(AS_CLOSE_GPIO_Port, AS_CLOSE_Pin, SET);
		continous_monitoring();
	}if( dati_as.stato == AS_STATE_FINISHED){
		ebs.state  &= 0b00000011;
	}
	// TODO da eliminare
	/*if(dati_as.asms == 0){
		if(vehicle_status.DBW1_TPS_error == 1 ){   //Apertura SDC ERRORE ASPIRAZIONE
			HAL_GPIO_WritePin(GPIOC	, GPIO_PIN_13, RESET);
		}
		else{
			HAL_GPIO_WritePin(GPIOC	, GPIO_PIN_13, SET);
		}
	}*/
}


void EBS_check(){

#ifdef BYPASSEBS
	HAL_Delay(1000);
	EBS_start_toggling_watchdog();
	ebs.state=EBS_STATE_ARMED;
	ebs.primo_check=ON;
	dati_as.asb_check = ON;
#endif

#ifndef BYPASSEBS

	//ebs.state=EBS_STATE_SDC_OPEN;
	EBS_start_toggling_watchdog();
	HAL_Delay(2000);
	ebs.sdc_ready=HAL_GPIO_ReadPin(EBS_READY_READ_GPIO_Port, EBS_READY_READ_Pin);
	if(ebs.sdc_ready==OFF){
		EBS_failure(EBS_STATE_FAILURE_SDC);
	}else {
		//ebs.state=EBS_STATE_SDC_READY;
		EBS_stop_toggling_watchdog();
		HAL_Delay(2000);
		ebs.sdc_ready=HAL_GPIO_ReadPin(EBS_READY_READ_GPIO_Port, EBS_READY_READ_Pin);
		if(ebs.sdc_ready==ON){
			EBS_failure(EBS_STATE_FAILURE_SDC);
		}
		else{
			//ebs.state=EBS_STATE_SDC_OPEN;
			EBS_start_toggling_watchdog();
			HAL_Delay(1000);
			if(((riferimenti_ia.ami < 0) || (riferimenti_ia.ami>6)) || dati_as.asms==ASMS_OFF ){
				EBS_failure(EBS_STATE_FAILURE_CHECK_AS);
			}else if(riferimenti_ia.ami>=0 && riferimenti_ia.ami < 7 && dati_as.asms==ASMS_ON){

				HAL_GPIO_WritePin(AS_CLOSE_GPIO_Port, AS_CLOSE_Pin, RESET);
				HAL_Delay(2000);
#ifdef	CHECKRMD

				RMD_X_V3_torque_closed_loop_control(&hcan2, ADDRESS_FRENO_TX, EBS_RMD_AMPERE_CONTROL_VALUE_ON, &RMD_freno);
				HAL_Delay(100);
				RMD_X_V3_torque_closed_loop_control(&hcan2, ADDRESS_FRENO_TX, EBS_RMD_AMPERE_CONTROL_VALUE_ON, &RMD_freno);
				HAL_Delay(100);
				RMD_X_V3_torque_closed_loop_control(&hcan2, ADDRESS_FRENO_TX, EBS_RMD_AMPERE_CONTROL_VALUE_ON, &RMD_freno);
				HAL_Delay(100);
				//EBS_check_brake_pressure();
				//ebs.brake_pressure = map((dati_dash.pompante_post+dati_dash.pompante_ant)/2,EBS_POMP_MIN,EBS_POMP_MAX,0,100);
				ebs.brake_pressure = map(dati_dash.pompante_ant,EBS_POMP_MIN,EBS_POMP_MAX,0,100);

				if(ebs.brake_pressure<EBS_SOGLIA_BRAKE_PRESSURE){
					EBS_stop_toggling_watchdog();
					EBS_failure(EBS_STATE_RMD_FAILURE);

				}else{
					RMD_X_V3_torque_closed_loop_control(&hcan2, ADDRESS_FRENO_TX, EBS_RMD_AMPERE_CONTROL_VALUE_OFF, &RMD_freno);
					HAL_Delay(100);
					RMD_X_V3_torque_closed_loop_control(&hcan2, ADDRESS_FRENO_TX, EBS_RMD_AMPERE_CONTROL_VALUE_OFF, &RMD_freno);
					HAL_Delay(100);
					RMD_X_V3_torque_closed_loop_control(&hcan2, ADDRESS_FRENO_TX, EBS_RMD_AMPERE_CONTROL_VALUE_OFF, &RMD_freno);
					HAL_Delay(100);
					//EBS_check_brake_pressure();
					//ebs.brake_pressure = map((dati_dash.pompante_post+dati_dash.pompante_ant)/2,EBS_POMP_MIN,EBS_POMP_MAX,0,100);
					ebs.brake_pressure = map(dati_dash.pompante_ant,EBS_POMP_MIN,EBS_POMP_MAX,0,100);

					if(!(ebs.brake_pressure>EBS_MIN_BRAKE_PRESSURE && ebs.brake_pressure<EBS_MAX_BRAKE_PRESSURE)){
						EBS_stop_toggling_watchdog();
						EBS_failure(EBS_STATE_RMD_FAILURE);
					}
					else{
#endif
				//ebs.state=EBS_STATE_SDC_READY;
				//EBS_check_energy_storage();//possiamo fare direttamente il map, o magari definirle come macro?
				ebs.energy_storage= brakesys_adc.press_ebs;//map (brakesys_adc.press_ebs,EBS_TANK_MIN,EBS_TANK_MAX,0,100);
				HAL_Delay(300);
				if(ebs.energy_storage < EBS_MIN_STORAGE){
					EBS_failure(EBS_STATE_FAILURE_ENERGY_STORAGE);
				}else{

					//ebs.state=EBS_STATE_ENERGY_STORAGE_FILLED;

					EBS_stop_toggling_watchdog();
					HAL_Delay(300);
					//EBS_check_brake_pressure();
					//ebs.brake_pressure = map((dati_dash.pompante_post+dati_dash.pompante_ant)/2,EBS_POMP_MIN,EBS_POMP_MAX,0,100);
					ebs.brake_pressure = brakesys_adc.press_ant;//map(brakesys_adc.press_ant,EBS_POMP_MIN,EBS_POMP_MAX,0,100);

					if(ebs.brake_pressure < EBS_SOGLIA_BRAKE_PRESSURE){
						EBS_failure(EBS_STATE_FAILURE_BRAKE_PRESSURE);
					}
					else{

						EBS_start_toggling_watchdog();
						HAL_Delay(300);
						//EBS_check_brake_pressure();
						//ebs.brake_pressure = map((dati_dash.pompante_post+dati_dash.pompante_ant)/2,EBS_POMP_MIN,EBS_POMP_MAX,0,100);
						ebs.brake_pressure = brakesys_adc.press_ant;//map(brakesys_adc.press_ant,EBS_POMP_MIN,EBS_POMP_MAX,0,100);

						if(!(ebs.brake_pressure>EBS_MIN_BRAKE_PRESSURE && ebs.brake_pressure<=EBS_MAX_BRAKE_PRESSURE)){
							EBS_stop_toggling_watchdog();
							EBS_failure(EBS_STATE_FAILURE_BRAKE_PRESSURE);
						}
						else{
							ebs.state=EBS_STATE_ARMED;
							ebs.primo_check=ON;
							dati_as.asb_check = ON;

						}
					}
				}
			}
		}
	}
#endif
}


void EBS_failure(int failure){
	ebs.state=failure;
	ebs.failureEBS=1;
	//HAL_GPIO_WritePin(EBS_FAILURE_GPIO_Port, EBS_FAILURE_Pin, SET);
}


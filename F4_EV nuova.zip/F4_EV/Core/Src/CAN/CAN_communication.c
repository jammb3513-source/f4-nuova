/*
 * CAN_communication.c
 *
 *  Created on: 16 mar 2022
 *      Author: Chip & Ciop
 *
 */


//TODO: reintegrare libreria e funzioni RMD freno

#include "can.h"
#include "AS/as.h"
#include "CAN/CAN_driver.h"
#include "CAN/CAN_communication.h"
#include "CHECK/check.h"
#include "EBS/ebs.h"
#include "FRENO/freno.h"
#include "STERZO/sterzo.h"
#include "map.h"
#include "IMD/IMD.h"
#include "settings.h"
#include <string.h>
#include "ADC/ADS1115.h"
#include "RMD_X_V3/RMD_X_V3_Communication.h"
#include "RMD_X_V3/RMD_X_V3_Controller.h"
#include "RMD_X_V3/RMD_X_V3_Command.h"

//INIZIO CAN_TRSMIT (simil 2021)
CAN_FilterTypeDef filter[FILTER_NUMBER];
CAN_TxHeaderTypeDef header;
uint16_t address_list[NUMBER_ADDRESS_MAX];

Can_Communication can_communication;
Sterzo_Freno_EBS sterzo_freno_EBS;
Volante volante;
FONICATA fonicata;
uint8_t test = 0;

Riferimenti_IA riferimenti_ia;
RES res;
/* TODO: quindi eliminiamo vehicle_status? */
//Vehicle_status vehicle_status;
Debug debug;

//CAN-INS
EulerAngles angle;
RateOfTurn rot;
Acceleration acceleration;
Velocity velocity;

//RMD Freno
extern RMD_X_V3_State RMD_freno;

//ADC potenziometri
extern Suspension_ADC suspension_adc;
extern BrakeSys_adc brakesys_adc;
extern CoolingSys_adc coolingsys_adc;
extern Vehicle_Status vehicle_status;

uint8_t	service_steering;
uint8_t Ricezione_RES[8];
uint8_t Cones_count_actual=0;
uint16_t Cones_count_all=0;

//questi primi messaggi non sono extern perchè vengono usati solo in questo file
uint8_t primo_messaggio_RES = 0;
uint8_t primo_messaggio_DASH = 0;
uint8_t primo_messaggio_volante = 0;

// var inviate sul CAN
uint8_t as_state = 0;
uint8_t steering_state = 0;
uint8_t service_brake_state = 1;



void CAN_transmit_Sterzo_Freno_EBS (CAN_HandleTypeDef* hcan){

	uint8_t data[CAN_DIM_ARRAY];
	sterzo_freno_EBS.as = dati_as.stato;
	sterzo_freno_EBS.ebs = ebs.state | (ebs.failureEBS << 4) ;
	/* TODO: chi fornisc throttle_position? */
	//sterzo_freno_EBS.throttle_position = vehicle_status.throttle_position;
	sterzo_freno_EBS.brake_state = brake.sb;
	/* TODO serve il /10 ? */
	sterzo_freno_EBS.brake_hydr_actual = brakesys_adc.press_ant / 10;//RMD_freno.torqueCurrent * 10;//CAN_BRAKE_MULTIPLIER*(dati_dash.potenziometro_volante - CAN_BRAKE_OFFSET);
	sterzo_freno_EBS.steering_state = steering.state;//(abs(RMD_sterzo.torqueCurrent)*CAN_TORQUE_MULTIPLIER) ; //ogni valore diviso 10

	service_steering = brake.sb | (steering.sa << 4);

	memcpy(data, &sterzo_freno_EBS, sizeof(Sterzo_Freno_EBS));

	can_communication.can1=CAN_Transmit(hcan, STERZO_FRENO_EBS, data,CAN_DIM_ARRAY) ;
	if(can_communication.can1 == HAL_ERROR){
		CAN_ErrorRestart(hcan);
	}
}

// inviava anche dati combustion
void CAN_transmit_dynamics1(CAN_HandleTypeDef* hcan){
	uint8_t data[CAN_DIM_ARRAY];

	data[0] = (uint8_t)fonicata.ant_sx;
	data[1] = riferimenti_ia.speed_target;
	data[2] = sterzo_freno_EBS.steering_actual;
	data[3] = (uint8_t)(riferimenti_ia.steering_target/2);
	data[4] = map(riferimenti_ia.brake_target, 0, 200, 0, 100);
	data[5] = map(brakesys_adc.press_post, 400, 4000, 0, 100);
//	data[6] = motor_moment;  // var eliminata
//	data[7] = motor_moment;

	can_communication.can1=CAN_Transmit(hcan, DV_DYNAMICS1, data, CAN_DIM_ARRAY);
	if(can_communication.can1 == HAL_ERROR){
		CAN_ErrorRestart(hcan);
	}
}

void CAN_transmit_dynamics2(CAN_HandleTypeDef* hcan){
	uint8_t data[CAN_DIM_ARRAY];

	// Acceleration longitudinal 0-15
	// Acceleration lateral 16-31
	// Yaw rate 32-47

	int16_t accelX_scaled= acceleration.accX/512;
	int16_t accelY_scaled = acceleration.accY/512;
	int16_t yaw_scaled = angle.yaw/128;

	// dati inviati in little endian
	data[0] = (int8_t)accelX_scaled; // acceleration x 8-15
	data[1] = (int8_t)accelX_scaled >> 8; // acceleration x 0-7
	data[2] = (int8_t)accelY_scaled; // acceleration y 8-15
	data[3] = (int8_t)accelY_scaled >> 8; // acceleration y 0-7
	data[4] = (int8_t)yaw_scaled; // yaw 8-15
	data[5] = (int8_t)yaw_scaled >> 8;  // yaw 0-7

	can_communication.can1=CAN_Transmit(hcan, DV_DYNAMICS2, data, CAN_DIM_ARRAY);
	if(can_communication.can1 == HAL_ERROR){
		CAN_ErrorRestart(hcan);
	}

}

void CAN_transmit_status(CAN_HandleTypeDef* hcan){
	uint8_t data[CAN_DIM_ARRAY];
	if(dati_as.stato == AS_STATE_CC) // cancellato "|| dati_as.stato == AS_METTI_MARCIA"
		as_state = AS_STATE_READY;
	else
		as_state = dati_as.stato;

	if(dati_as.asms == 1)
		steering_state = 1;
	else
		steering_state = 0;

	if(brake.turn_on == 0)
		service_brake_state = 1;
	else if(brake.turn_on == 1 && prova_freno < 0.5)
		service_brake_state = 3;
	else
		service_brake_state = 2;

	// TODO eliminare func combustion... ma questa sembra importante?? per via del conteggio coni
//	if(dati_as.stato == AS_STATE_DRIVING && Cones_count_all <= 70){
//		if(vehicle_status.RPM < 3000)
//			Cones_count_actual = 2;
//		else if(vehicle_status.RPM >= 3000 && vehicle_status.RPM < 5000)
//			Cones_count_actual = 5;
//		else if(vehicle_status.RPM >= 5000 && vehicle_status.RPM < 8500)
//			Cones_count_actual = 3;
//		else
//			Cones_count_actual = 6;
//
//		Cones_count_all += Cones_count_actual;
//	}

	uint8_t ami = 3;

	data[0] = ami  << 5 | (ebs.state & 0b00000011)  << 3 | as_state;
	data[1] = Cones_count_actual << 7| riferimenti_ia.FLAG_futuro << 3| service_brake_state << 1 | steering_state;
	data[2] = Cones_count_all << 7 | Cones_count_actual >> 1;
	data[3] = Cones_count_all >> 1;
	data[4] = Cones_count_all >> 9;

	can_communication.can1=CAN_Transmit(hcan, DV_SYSTEM_STATUS, data, CAN_DIM_ARRAY) ;
	if(can_communication.can1 == HAL_ERROR){
		CAN_ErrorRestart(hcan);
	}
}

//Status RMD
void CAN_transmit_Stato_RMD(CAN_HandleTypeDef* hcan){

	uint8_t data[CAN_DIM_ARRAY];

   /* TODO: SUS misurare il voltaggio col pompante*/
	if(brakesys_adc.press_post < 12)
		stato_RMD.voltaggio_batteria_48V = 0;
	else{

		if(brakesys_adc.press_post > 10000)
			stato_RMD.voltaggio_batteria_48V =500 / 20;//( ((float)(dati_dash.pompante_ant*0.011))-4.44)*10;
		else
			stato_RMD.voltaggio_batteria_48V = brakesys_adc.press_post / 20;
	}

	stato_RMD.freno_temperatura = RMD_freno.motorTemperature;


	memcpy(data, &stato_RMD, sizeof(Stato_RMD));	//è GIUSTO?

	can_communication.can1 = CAN_Transmit(hcan, ADDRESS_STATO_RMD, data, CAN_DIM_ARRAY);
	if(can_communication.can1 == HAL_ERROR){
		HAL_CAN_AbortTxRequest(hcan, CAN_TX_MAILBOX0);
		HAL_CAN_AbortTxRequest(hcan, CAN_TX_MAILBOX1);
		HAL_CAN_AbortTxRequest(hcan, CAN_TX_MAILBOX2);
		HAL_CAN_ResetError(hcan);
		HAL_CAN_Stop(hcan);
		HAL_CAN_Start(hcan);
	}
}

//RES BOOT-RES ADDRESS//
HAL_StatusTypeDef CAN_RES_Setup (CAN_HandleTypeDef* hcan) {

	if ((hcan == NULL))
		return HAL_ERROR;

	uint8_t data[25];

	uint8_t res_boot[2];
	res_boot[0] = 0x01;
	res_boot[1] = 0x00;

	CAN_serializate_gen(data, (void*) res_boot, sizeof(res_boot));

	header.DLC = 2;
	header.IDE = CAN_ID_STD;
	header.RTR = CAN_RTR_DATA;
	header.StdId = 0; //il nostro id

	return HAL_CAN_AddTxMessage(hcan, &header, data, &mailbox);
}

void CAN_transmit_vehicle_status_1( CAN_HandleTypeDef* hcan){
	uint8_t data[CAN_DIM_ARRAY];
    //Invia valori di ogni sospensione su 2 byte quindi da 0 a 6000 che corrispndono a 0v - 6.000v
	data[0] = (uint16_t)(suspension_adc.ant_dx*1000);
	data[1] = (uint8_t) ( ((uint16_t)(suspension_adc.ant_dx*1000)) >>8);
	data[2] = (uint16_t)(suspension_adc.ant_sx*1000);
	data[3] = (uint8_t) ( ((uint16_t)(suspension_adc.ant_sx*1000)) >>8);
	data[4] = (uint16_t)(suspension_adc.post_dx*1000);
	data[5] = (uint8_t) ( ((uint16_t)(suspension_adc.post_dx*1000)) >>8);
	data[6] = (uint16_t)(suspension_adc.post_dx*1000);
	data[7] = (uint8_t) ( ((uint16_t)(suspension_adc.post_dx*1000)) >>8);

	can_communication.can1=CAN_Transmit(hcan, VEHICLE_STATUS_1, data, CAN_DIM_ARRAY);
	if(can_communication.can1 == HAL_ERROR){
		CAN_ErrorRestart(hcan);
	}
}

void CAN_transmit_vehicle_status_2( CAN_HandleTypeDef* hcan){
	uint8_t data[CAN_DIM_ARRAY];
    //Invia valori di ogni sospensione su 2 byte quindi da 0 a 6000 che corrispndono a 0v - 6.000v
	data[0] = (uint16_t)(brakesys_adc.press_ant*1000);
	data[1] = (uint8_t) ( ((uint16_t)(brakesys_adc.press_ant*1000)) >>8);
	data[0] = (uint16_t)(brakesys_adc.press_post*1000);
	data[1] = (uint8_t) ( ((uint16_t)(brakesys_adc.press_post*1000)) >>8);
	data[4] = (uint16_t)(brakesys_adc.press_ebs*1000);
	data[5] = (uint8_t) ( ((uint16_t)(brakesys_adc.press_ebs*1000)) >>8);
	float temp_rad_tmp = (coolingsys_adc.temp_rad_dx + coolingsys_adc.temp_rad_sx)/2;
	data[6] = (uint8_t) ( ((uint16_t)(temp_rad_tmp*100))/3 ); //scaling *100/3
	data[7] = (uint8_t) ( ((uint16_t)(vehicle_status.voltage_24v*100))/2);

	can_communication.can1=CAN_Transmit(hcan, VEHICLE_STATUS_1, data, CAN_DIM_ARRAY);
	if(can_communication.can1 == HAL_ERROR){
		CAN_ErrorRestart(hcan);
	}
}

void CAN_receive_state(uint8_t data[],CAN_RxHeaderTypeDef My_header){
	//TODO:questa assegnazione va fatta nel task dove serve (questo comm. è stato scritto molto prima della pulizia)
	//steering.potenziometro_sterzo = dati_dash.potenziometro_volante;

	if (My_header.StdId == 0x711){
			CAN_RES_Setup(&hcan1);
		}
	else if (My_header.StdId == RES_ADDRESS){
		CAN_deserializate_gen(data, &Ricezione_RES, sizeof(Ricezione_RES));
		res.emergenza = Ricezione_RES[0] & 0x01;
		res.enable_go = (Ricezione_RES[0] & 0x02) >>1;
		res.go = (Ricezione_RES[0] & 0x04) >>2;
		if(primo_messaggio_RES==0){
				primo_messaggio_RES=1;
				}
		//res.last_message=HAL_GetTick();
		}

	else if (My_header.StdId == VOLANTE){
//		volante.potenziometro_frizione = data[0];
//		volante.paddle = data[1];
		volante.AMI_provvisorio = data[2];
		volante.AMI_comunicato = data[3];
		volante.LC_TC = data[4];
		volante.radio = data[5];
		volante.jatson = data[6];
		volante.antiroll_DRS = data[7];

		if(primo_messaggio_volante == 0){
			primo_messaggio_volante = 1;
		}
		if((volante.jatson > 1 || debug.drs == 1) && brakesys_adc.press_ant < 700){
			debug.drs = 1;
		}else{
			debug.drs = 0;
		}

	}
	// TODO: rimuovere fonicata?
	else if(My_header.StdId == 0x150){
		CAN_deserializate_gen(data, &fonicata, sizeof(fonicata));
			fonicata.ant_dx = ((data[1] << 8) | (data[0]))*0.1;
			fonicata.ant_sx = ((data[3] << 8) | (data[2]))*0.1;
			fonicata.post_dx = ((data[5] << 8) | (data[4]))*0.1;
			fonicata.post_sx = ((data[7] << 8) | (data[6]))*0.1;

	}
	else if(My_header.StdId == DASH_STATUS){
		//CAN_deserializate_gen(data, &dash_status, sizeof(Dash_status));

		if(primo_messaggio_DASH==0){
			primo_messaggio_DASH=1;
		}
	}
	else if(My_header.StdId == IMD_INFO_GENERAL){
		IMD_Deserialize_Status(data);
	}

	if (My_header.StdId == RIFERIMENTI_IA || test == 1){
		//CAN_deserializate_gen(data, &riferimenti_ia, sizeof(RIFERIMENTI_IA));
		riferimenti_ia.perc_acceleratore = data[0];
		riferimenti_ia.speed_target = data[1];
		riferimenti_ia.steering_target = data[2] | (data[3] << 8);//dirgli di inviargli al contrario (littol endia) e usare la funzione deserializate
		riferimenti_ia.brake_target = data[4];
		riferimenti_ia.mission_finished = data[5];
		riferimenti_ia.ami = data[6];
		riferimenti_ia.FLAG_futuro = data[7];
		//isBraking = data[7];
		dati_as.mission = riferimenti_ia.ami;

		//ATTUAZIONE STERZO
		/* TODO: L'attuazione più attesa del 2025 */
		if(dati_as.stato == AS_STATE_DRIVING && flag_sterzo==1){
			if(riferimenti_ia.steering_target < -160)
				riferimenti_ia.steering_target = -160;
			if(riferimenti_ia.steering_target > 160)
				riferimenti_ia.steering_target = 160;

			steering.offset = 0; //Correzione in gradi dell'angolo di sterzo
			//steering.angle = ((riferimenti_ia.steering_target + steering.offset) * STERZO_COMPENSAZIONE_VAL_RID/* 1.77*/); //+ steering.offset;
			steering.angle = riferimenti_ia.steering_target;
			//EPOS4_SetTargetAngleDeg(steering.angle);
		}

		//ATTUAZIONE FRENO
		if(dati_as.stato == AS_STATE_DRIVING && brake_emergency !=1){
			prova_freno = map(riferimenti_ia.brake_target, 0, 200, FRENO_LIMIT_INF, FRENO_LIMIT_SUP);
			//RMD_X_torque_control(&hcan2,ADDRESS_FRENO_TX,prova_freno,&RMD_freno);//controlla verso di rotazione
			RMD_X_V3_torque_closed_loop_control(&hcan2,ADDRESS_FRENO_TX,prova_freno,&RMD_freno);//controlla verso di rotazione

		}else if (dati_as.stato == AS_STATE_CC){
			prova_freno = 2;
			//RMD_X_torque_control(&hcan2,ADDRESS_FRENO_TX,prova_freno,&RMD_freno);//controlla verso di rotazione
			RMD_X_V3_torque_closed_loop_control(&hcan2,ADDRESS_FRENO_TX,prova_freno,&RMD_freno);//controlla verso di rotazione

			brake.sb = SB_ENGAGED;

		}else if(brake_emergency == 1){
			prova_freno = 3;
			//RMD_X_torque_control(&hcan2,ADDRESS_FRENO_TX,prova_freno,&RMD_freno);
			RMD_X_V3_torque_closed_loop_control(&hcan2,ADDRESS_FRENO_TX,prova_freno,&RMD_freno);
		}

		if(primo_messaggio_AI==0){
			primo_messaggio_AI=1;
		}
	}

	// CAN-INS
	switch (My_header.StdId) {
		case EULER_ANGLES:
			angle.roll = (int16_t)((data[0] << 8) | data[1]); // I byte più significativi vengono prima essendo i dati big-endian
			angle.pitch = (int16_t)((data[2] << 8) | data[3]);
			angle.yaw = (int16_t)((data[4] << 8) | data[5]);

			break;

		case RATE_OF_TURN:
			rot.gyrX = (int16_t)((data[0] << 8) | data[1]);
			rot.gyrY = (int16_t)((data[2] << 8) | data[3]);
			rot.gyrZ = (int16_t)((data[4] << 8) | data[5]);

			break;

		case ACCELERATION:
			acceleration.accX = (int16_t)((data[0] << 8) | data[1]);
			acceleration.accY = (int16_t)((data[2] << 8) | data[3]);
			acceleration.accZ = (int16_t)((data[4] << 8) | data[5]);

			break;

		case VELOCITY:
			velocity.velX = (int16_t)((data[0] << 8) | data[1]);
			velocity.velY = (int16_t)((data[2] << 8) | data[3]);
			velocity.velZ = (int16_t)((data[4] << 8) | data[5]);

			break;

		default:
			break;
	}
}


//TODO: rendere macro
void CAN_serializate_gen(uint8_t data_out[], void* data_in, unsigned int dim_struct){
	memcpy(data_out,data_in,dim_struct);
}

void CAN_deserializate_gen(uint8_t data_in[], void* data_out, unsigned int dim_struct){
	memcpy(data_out,data_in,dim_struct);
}

void CAN_ErrorRestart(CAN_HandleTypeDef* hcan){
	HAL_CAN_AbortTxRequest(hcan, CAN_TX_MAILBOX0);
	HAL_CAN_AbortTxRequest(hcan, CAN_TX_MAILBOX1);
	HAL_CAN_AbortTxRequest(hcan, CAN_TX_MAILBOX2);
	HAL_CAN_ResetError(hcan);
	HAL_CAN_Stop(hcan);
	HAL_CAN_Start(hcan);
}


void CAN_sendStatus_IMD_OK(CAN_HandleTypeDef* hcan){
	//manda Status_OK via CAN per abbassare il pin di Alarm sulla IMD

	uint8_t data[CAN_DIM_ARRAY];

	// self-holding iso-Alarm: Reset Alarm
	// ID: 0x22
	// index: 0x33
	// data1: 0x01

	data[0] = IMD_I_RESET_ALARM; // index
	data[1] = 0x01; // data1 (reset alarm)

	can_communication.can1=CAN_Transmit(hcan, IMD_REQUEST, data, CAN_DIM_ARRAY);
	if(can_communication.can1 == HAL_ERROR){
		CAN_ErrorRestart(hcan);
	}
}


/*
 * sterzo.c
 *
 *  Created on: Feb 21, 2022
 *      Author: chip & ciop
 */
#include "STERZO/sterzo.h"

uint8_t primo_messaggio_sterzo;  // TODO primo_messaggio_sterzo viene definito dagli RMD nella callback CAN
// senza il codice degli RMD questa variabile non commuta mai a 1 e non entra nel check (check.c riga 50)

STERZO steering;
uint8_t flag_sterzo=0;

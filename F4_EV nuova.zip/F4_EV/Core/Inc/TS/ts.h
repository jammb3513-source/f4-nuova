/*
 * ts.h
 *
 *  Created on: Aug 20, 2025
 *      Author: david
 */

#ifndef INC_TS_TS_H_
#define INC_TS_TS_H_

#include "main.h"

#define TS_OFF			0
#define TS_ON			1
#define R2D_ACTIVE		2
#define TS_EMERGENCY	3
#define TS_AS			4

#define TS_BUZZER_DURATION 2000 //ms

extern uint32_t press ;
extern uint8_t flag_on;
typedef struct TS{
	uint8_t TSMS;
	uint8_t status;
	uint8_t EV_button;
	uint8_t DV_button;
}TS;
extern TS ts;

void TS_Activation();
void TS_R2D_buzzer_on();
void TS_R2D_buzzer_off();

#endif /* INC_TS_TS_H_ */

/*
 * check.h
 *
 *  Created on: Feb 22, 2022
 *      Author: chip & ciop
 */

extern float prova_freno;

#ifndef INC_CHECK_CHECK_H_
#define INC_CHECK_CHECK_H_

//#include "main.h"
#define SOGLIA_EMERGENZA_FRENO	 1000
#define SOGLIA_EMERGENZA_STERZO	 1000 //todo: verificare se è la stessa di prima

#define SOGLIA_EMERGENZA_IA      1000
#define SOGLIA_EMERGENZA_DATI_DASH 1000
#define SOGLIA_EMERGENZA_RES      500

// usate solo da brake e steering, i nomi sono ambigui, meglio rinominarle
#define STATO_CAN_ON			1
#define STATO_CAN_OFF			0

void freno_check();
void sterzo_check();
void continous_monitoring();
#endif /* INC_CHECK_CHECK_H_ */

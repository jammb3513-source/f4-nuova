/*
 * as.h
 *
 *  Created on: Feb 19, 2022
 *      Author: Chip & Ciop
 */

#ifndef INC_AS_AS_H_
#define INC_AS_AS_H_
#include "main.h"

#define ON 1
#define OFF 0

#define R2D_ON                1
#define R2D_OFF               0

#define ASMS_OFF 	          0
#define ASMS_ON               1

#define ASB_OFF 	          0
#define ASB_ON                1

#define AS_STATE_MANUAL        0  //inutilizzato
#define AS_STATE_OFF           1
#define AS_STATE_READY         2
#define AS_STATE_DRIVING       3
#define AS_STATE_EMERGENCY     4
#define AS_STATE_FINISHED      5
#define AS_STATE_CC            6 // STATO REGOLAMENTARE OFF

extern uint8_t primo_messaggio_AI;



typedef struct Dati_AS{
	uint8_t stato;
	uint8_t TS; //usata solo all'inizio di Driverless_ON(), mai scritta
	uint8_t mission;
	uint8_t asms;
	uint8_t r2d; //usata solo in AS_task()
	uint8_t speed; //usata solo in AS_setup_dati()
	uint8_t sound;
	uint8_t asb_check;
	uint8_t sdc; //usata solo in AS_setup_dati()
	uint8_t timer_Delay; //usata solo in AS_init()
}Dati_AS;
extern Dati_AS dati_as;



void AS_finished();
void AS_setup_dati();
void AS_task();
void AS_driving();
void AS_ready();
void AS_off();
void AS_init();
void AS_emergency();
void AS_start_delay_count();
#endif /* INC_AS_AS_H_ */

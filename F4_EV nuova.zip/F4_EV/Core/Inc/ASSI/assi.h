/*
 * assi.h
 *
 *  Created on: Feb 22, 2022
 *      Author: chip & ciop
 */
#ifndef INC_ASSI_ASSI_H_
#define INC_ASSI_ASSI_H_

#define PIN_LED_BLUE_PORT			&htim3
#define PIN_LED_BLUE				TIM_CHANNEL_1
#define PIN_LED_GREEN_PORT			&htim3
#define PIN_LED_GREEN				TIM_CHANNEL_2
#define PIN_LED_RED_PORT			&htim3
#define PIN_LED_RED					TIM_CHANNEL_3
#define PIN_BUZZER_PORT				&htim3
#define PIN_BUZZER					TIM_CHANNEL_4

#define LED_ON 10000
#define LED_OFF 0
#define LED_FLASHING 5000
#define BUZZER_ON 5000
#define BUZZER_OFF 0

#define ASSI_blue_flashing 0
#define ASSI_blue_continuous 1
#define ASSI_yellow_flashing 2
#define ASSI_yellow_continuous 3

void ASSI_init();
void ASSI_off();
void ASSI_set_flashingBuzzer(int value);


#endif /* INC_ASSI_ASSI_H_ */

/*
 * settings.h
 *
 *  Created on: 10 gen 2023
 *      Author: filip
 */

#ifndef INC_SETTINGS_H_
#define INC_SETTINGS_H_

// Sono state commentate tutte le define non utilizzate nel codice
// ma non sono state eliminate perchè potrebbero essere valori importanti
// nel caso verranno eliminate successivamente


/*  CHECK  */
#define CHECK_MIN_PRESS_POMP				1

/*  EBS  */
//#define EBS_RMD_AMPERE_CONTROL_VALUE_ON  	2
//#define EBS_RMD_AMPERE_CONTROL_VALUE_OFF	0.1
#define EBS_TANK_MIN                        25//1000 //31bar
#define EBS_TANK_MAX                        50//2000
#define EBS_POMP_MIN                        1//300
#define EBS_POMP_MAX                        50//5000
#define EBS_SOGLIA_BRAKE_PRESSURE			3//5
#define EBS_MIN_BRAKE_PRESSURE				1
#define EBS_MAX_BRAKE_PRESSURE				50
#define EBS_MIN_STORAGE              	    30

/*  FRENO  */
//#define FRENO_RMD_AMPERE_CONTROL_VALUE_0	0
//#define FRENO_REDUCTION_RATIO_9				1
//#define FRENO_PRESS_POMP_ANT_MAX       		4
//#define FRENO_PRESS_POMP_ANT_MIN       		1
//#define FRENO_PRESS_POMP_POST_MAX      		4
//#define FRENO_PRESS_POMP_POST_MIN      		0
//#define FRENO_ENGAGED_PERC       			25 //50
//#define FRENO_RELEASED_PRESSURE  			550
//#define FRENO_LIMIT_RPM_40       			40
#define FRENO_LIMIT_INF						0.1
#define FRENO_LIMIT_SUP						5

/*	STERZO  */
//#define STERZO_REDUCTION_RATIO_6			1
//#define STERZO_LIMIT_RPM_CONTROL_90			130
//#define STERZO_LIMIT_RPM_CONTROL_40         40
//#define STERZO_POTENZIOMETRO_VOLANTE_MIN	1900
//#define STERZO_POTENZIOMETRO_VOLANTE_MAX	1940
//#define STERZO_INCREASE_OFFSET				3
//#define STERZO_DECREASE_OFFSET				3
//#define STERZO_STEERING_TARGET_MIN			-130
//#define STERZO_STEERING_TARGET_MAX			130
//#define STERZ0_VELOCITA_MAX					80
//#define STERZ0_VELOCITA_MIN					60
#define STERZO_COMPENSAZIONE_VAL_RID		1.5
//#define STERZO_RMD_AMPERE_CONTROL_VALUE_0	0
//#define STERZO_MIN_ANGLE                  	-150
//#define STERZO_MAX_ANGLE                   	150

/*	CAN  */
#define CAN_DIM_ARRAY				8
//#define CAN_BRAKE_MULTIPLIER 		0.0483 //0.0966	//moltiplicatore usato in CAN_trasmit_Sterzo_Freno_EBS per settare brake_hydr_actual
//#define CAN_BRAKE_OFFSET        	1770 //170.97	//offset usato in CAN_transmit_Sterzo_Freno_EBS per settare brake_hydr_actual
//#define CAN_STEERING_MULTIPLIER 	0.33333		//ho inglobato la divisione per 1.5 e per 2
//#define CAN_TORQUE_MULTIPLIER		10		//moltiplicando utilizzato in CAN_transmit_Sterzo_Freno_EBS e in CAN_transmit_Debug sul torqueCurrent


#endif /* INC_SETTINGS_H_ */

/*
 * cooling.h
 *
 *  Created on: Sep 4, 2025
 *      Author: fabio
 */

#ifndef INC_COOLING_COOLING_H_
#define INC_COOLING_COOLING_H_
#include "main.h"
#include "ADC/ADS1115.h"

// ===================== PARAMETRI CONFIGURABILI RADIATORE =====================
// Temperature di controllo RADIATORE (SINGOLO SENSORE)
#define TEMP_RAD_TARGET           30.0f   // Temperatura target radiatore

#define TEMP_RAD_FAN_START        88.0f   // Inizio azione ventole radiatore
#define TEMP_RAD_EMERGENCY       105.0f   // Emergenza radiatore
#define TEMP_RAD_HYSTERESIS       5.0f    // Isteresi per spegnimento radiatore

// Parametri pompa acqua (configurabili)
#define PUMP_MIN_SPEED        10.0f   // Velocità minima pompa (%)
#define PUMP_MAX_SPEED        100.0f   // Velocità massima pompa (%)


// ===================== PARAMETRI CONFIGURABILI TSAC =====================
// Temperature di controllo TSAC (SENSORE INDIPENDENTE)
#define TEMP_TSAC_TARGET          75.0f   // Temperatura target TSAC
#define TEMP_TSAC_FAN_START       78.0f   // Inizio azione ventole TSAC
#define TEMP_TSAC_EMERGENCY       95.0f   // Emergenza TSAC

#define FAN_MIN_SPEED         10.0f   // Velocità minima ventole TSAC (%)
#define FAN_MAX_SPEED         100.0f  // Velocità massima ventole TSAC (%)

// ===================== CONFIGURAZIONE PIN DI CONTROLLO =====================
// Definisci qui i pin GPIO per i relè (esempio con GPIO_TypeDef)
#define PUMP_RELAY_GPIO_PORT      POMPE_CTRL_GPIO_Port     // Porta GPIO per relè pompa
#define PUMP_RELAY_GPIO_PIN       POMPE_CTRL_Pin // Pin GPIO per relè pompa

#define RAD_FAN_RELAY_GPIO_PORT   VENTOLE_RAD_CTRL_GPIO_Port     // Porta GPIO per relè ventole radiatore
#define RAD_FAN_RELAY_GPIO_PIN    VENTOLE_RAD_CTRL_Pin // Pin GPIO per relè ventole radiatore

// ===================== PWM HARDWARE (SOLO PER POMPA) =====================
#define PUMP_PWM_MIN          0
#define PUMP_PWM_MAX          1000

typedef struct {
    // Sistema Radiatore
    float radiator_temperature;
    int pump_active;
    int pump_relay_on;
    int rad_fan_active;
    int rad_fan_relay_on;
    float pump_speed;
    uint16_t pump_pwm;

    // Sistema TSAC
    float tsac_temperature;
    int tsac_fan_active;
    int tsac_fan_relay_on;
} cooling_status_t;

void Cooling_Control();


#endif /* INC_COOLING_COOLING_H_ */

/*
 * CAN_driver.h
 *
 *  Created on: Feb 4, 2022
 *      Author: bianc
 */

#ifndef INC_CAN_CAN_DRIVER_H_
#define INC_CAN_CAN_DRIVER_H_

#include "main.h"

extern uint32_t mailbox;

HAL_StatusTypeDef CAN_Receive(CAN_HandleTypeDef* hcan, uint32_t* my_id, uint8_t* data, uint8_t queue_number);
HAL_StatusTypeDef CAN_Transmit(CAN_HandleTypeDef* hcan, uint32_t my_id, uint8_t* data, uint8_t data_length) ;


#endif /* INC_CAN_CAN_DRIVER_H_ */

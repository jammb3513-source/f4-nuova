#pragma once
#include "stm32f4xx_hal.h"
#include <stdint.h>

#define EPOS4_NODE_ID 1

typedef enum {
  EPOS4_OK = 0,
  EPOS4_ERR_TIMEOUT,
  EPOS4_ERR_COMM,
  EPOS4_ERR_STATE,
  EPOS4_ERR_PARAM
} EPOS4_Result;

typedef enum {
  EPOS4_MODE_PP  = 1,
  EPOS4_MODE_CSP = 8
} EPOS4_Mode;

typedef struct {
  CAN_HandleTypeDef* hcan;
  uint8_t  node_id;            // 1..127
  EPOS4_Mode mode;             // noi dovremmo scegliere CSP, cioè 8
  uint32_t heartbeat_ms;       // es. 200
  uint32_t sync_period_us;     // es. 1000 us
  // Conversioni:
  float    gear_ratio;         //
  uint32_t counts_per_rev;     // CPR effettivo encoder
} EPOS4_Config;

typedef struct {
  uint16_t statusword;     // 0x6041
  int32_t  pos_actual;     // 0x6064
  uint8_t  op_enabled;     // derived da statusword
  uint8_t  fault;          // derived da statusword
  uint32_t last_hb_ms;     // ultimo heartbeat
} EPOS4_State;
